import React from 'react';
import { AppBar, Toolbar, Typography, Button, IconButton } from '@mui/material';
import { Link } from 'react-router-dom';
import MenuBookIcon from '@mui/icons-material/MenuBook';

const Navbar = () => {
    return (
        <AppBar position="static" sx={{ flexGrow: 1, backgroundColor: '#C71585' }}>
            <Toolbar>
                <IconButton
                    edge="start"
                    color="inherit"
                    aria-label="menu"
                    sx={{ marginRight: 2 }}
                >
                    <MenuBookIcon />
                </IconButton>
                <Typography variant="h6" sx={{ flexGrow: 1 }}>
                    Books
                </Typography>
                <Button
                    color="inherit"
                    component={Link}
                    to="/register"
                    sx={{
                        '&:hover': {
                            backgroundColor: '#C71585', // Change hover color to match primary color
                        },
                    }}
                >
                    Register
                </Button>
                <Button
                    color="inherit"
                    component={Link}
                    to="/admin-register"
                    sx={{
                        '&:hover': {
                            backgroundColor: '#C71585', // Change hover color to match primary color
                        },
                    }}
                >
                    Admin
                </Button>
            </Toolbar>
        </AppBar>
    );
};

export default Navbar;
