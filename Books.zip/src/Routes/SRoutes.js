import React from 'react';
import { Routes, Route } from 'react-router-dom';
import RegisterPage from '../Pages/RegisterPage';

import HomePage from '../Pages/HomePage';
import BrowseProducts from '../Pages/BrowseProducts';
import LoginPage from '../Pages/LoginPage';
import AdminRegister from '../Pages/AdminRegister';
import AdminLogin from '../Pages/AdminLogin';
import AdminDashboard from '../Pages/AdminDashboard';
import ManageBooks from '../Pages/ManageBooks';
import ViewData from '../Pages/ViewData';

const SRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/register" element={<RegisterPage />} />
      
      <Route path="/browse-products" element={<BrowseProducts/>} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/admin-register" element={<AdminRegister />} />
      <Route path="/admin-login" element={<AdminLogin />} />
      <Route path="/admin-dashboard" element={<AdminDashboard />} />  {/* Admin Dashboard */}
      <Route path="/ManageBooks" element={<ManageBooks />} />
      <Route path="/ViewData" element={<ViewData />} />
    </Routes>
  );
};

export default SRoutes;