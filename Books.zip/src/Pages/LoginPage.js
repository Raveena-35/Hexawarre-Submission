import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { styled } from '@mui/system';

const LoginContainer = styled(Container)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  marginTop: theme.spacing(8),
  padding: theme.spacing(4),
  borderRadius: '8px',
  backgroundColor: '#f5f5f5', // Keep the light background for contrast
  boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
}));

const LoginIconBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#C71585', // Pink color for the icon wrapper
  borderRadius: '50%',
  width: '80px',
  height: '80px',
  marginBottom: theme.spacing(2),
}));

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    const payload = {
      email: email,
      password: password,
    };

    try {
      const response = await fetch('http://localhost:8080/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        setError('Invalid email or password');
      } else {
        const data = await response.json();
        localStorage.setItem('token', data.jwt);  // Store JWT
        navigate('/browse-products');  // Redirect to Browse Products page after successful login
      }
    } catch (err) {
      setError('Failed to login. Try again later.');
    }
  };

  return (
    <LoginContainer maxWidth="xs">
      <LoginIconBox>
        <LockOutlinedIcon sx={{ color: '#fff', fontSize: 40 }} />
      </LoginIconBox>
      <Typography variant="h5" gutterBottom sx={{ color: '#C71585', fontWeight: 'bold' }}> {/* Changed to pink */}
        Sign In
      </Typography>
      {error && <Alert severity="error" sx={{ width: '100%', marginBottom: 2 }}>{error}</Alert>}
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        InputLabelProps={{
          style: { color: '#616161' },
        }}
      />
      <TextField
        label="Password"
        variant="outlined"
        fullWidth
        type="password"
        margin="normal"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        InputLabelProps={{
          style: { color: '#616161' },
        }}
      />
      <Button
        variant="contained"
        color="primary"
        fullWidth
        onClick={handleLogin}
        sx={{ marginTop: 2, padding: '10px 0', fontWeight: 'bold', backgroundColor: '#C71585' }} // Pink color for the button
      >
        Login
      </Button>
    </LoginContainer>
  );
};

export default Login;
