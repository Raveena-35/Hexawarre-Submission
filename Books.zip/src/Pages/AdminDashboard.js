import React, { useState } from 'react';
import {
  Button,
  Container,
  Box,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  AppBar,
  Toolbar,
  useTheme,
} from '@mui/material';
import { Book, Visibility } from '@mui/icons-material'; // Import Material UI icons
import ManageBooks from './ManageBooks';
import ViewData from './ViewData';

const AdminDashboard = () => {
  const [openManageBooks, setOpenManageBooks] = useState(false);
  const [openViewData, setOpenViewData] = useState(false);
  const theme = useTheme(); // Access the theme for colors

  const handleManageBooksOpen = () => setOpenManageBooks(true);
  const handleManageBooksClose = () => setOpenManageBooks(false);

  const handleViewDataOpen = () => setOpenViewData(true);
  const handleViewDataClose = () => setOpenViewData(false);

  return (
    <Container>
      <AppBar position="static" sx={{ backgroundColor: '#C71585' }}>
        <Toolbar>
          <Typography variant="h6">Book Management Admin</Typography>
        </Toolbar>
      </AppBar>
      <Box mt={4} mb={4} textAlign="center" sx={{ backgroundColor: theme.palette.grey[100], borderRadius: '8px', padding: '20px' }}>
        <Typography variant="h4" gutterBottom color="#C71585">
          Admin Dashboard
        </Typography>
        <Button
          variant="contained"
          sx={{ backgroundColor: '#C71585', '&:hover': { backgroundColor: '#C71585' } }} // Use pink color
          onClick={handleManageBooksOpen}
          startIcon={<Book />}
        >
          Manage Books
        </Button>
        <Button
          variant="contained"
          sx={{ backgroundColor: '#C71585', '&:hover': { backgroundColor: '#C71585' }, marginLeft: '16px' }} // Use pink color
          onClick={handleViewDataOpen}
          startIcon={<Visibility />}
        >
          View Data
        </Button>
      </Box>

      {/* Manage Books Modal */}
      <Dialog open={openManageBooks} onClose={handleManageBooksClose} fullWidth maxWidth="md">
        <DialogTitle>Manage Books</DialogTitle>
        <DialogContent>
          <ManageBooks />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleManageBooksClose} sx={{ color: '#C71585' }}>
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* View Data Modal */}
      <Dialog open={openViewData} onClose={handleViewDataClose} fullWidth maxWidth="md">
        <DialogTitle>View Data</DialogTitle>
        <DialogContent>
          <ViewData />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleViewDataClose} sx={{ color: '#C71585' }}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminDashboard;
