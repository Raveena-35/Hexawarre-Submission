import React, { useState } from 'react';
import {
  TextField,
  Button,
  Container,
  Typography,
  Snackbar,
  Box,
  Card,
  CardContent,
  AppBar,
  Toolbar,
  IconButton,
  useTheme,
} from '@mui/material';
import { AddCircle } from '@mui/icons-material'; // Import icon for adding a book

const ManageBook = () => {
  const [book, setBook] = useState({
    isbn: '',
    title: '',
    author: '',
    publicationYear: '',
    imageUrl: ''
  });
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const theme = useTheme(); // Access the theme for consistent colors

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBook({ ...book, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:8080/api/admin/addNewBook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(book)
      });
      if (response.ok) {
        const data = await response.json();
        console.log('Book added:', data);
        setMessage('Book added successfully!');
        setOpen(true);
        // Clear the form
        setBook({
          isbn: '',
          title: '',
          author: '',
          publicationYear: '',
          imageUrl: ''
        });
      } else {
        setMessage('Error adding book');
        setOpen(true);
      }
    } catch (error) {
      console.error('Error adding book:', error);
      setMessage('Error adding book');
      setOpen(true);
    }
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Container>
      <AppBar position="static" sx={{ backgroundColor: '#C71585' }}>
        <Toolbar>
          <Typography variant="h6">Book Management</Typography>
        </Toolbar>
      </AppBar>

      <Box mt={4} mb={4}>
        <Card variant="outlined" sx={{ padding: 2 }}>
          <CardContent>
            <Typography variant="h4" gutterBottom color="#C71585">
              Add New Book
            </Typography>
            <form onSubmit={handleSubmit}>
              <TextField
                label="ISBN"
                name="isbn"
                value={book.isbn}
                onChange={handleChange}
                fullWidth
                margin="normal"
                required
                sx={{ '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': { borderColor: '#C71585' } }} // Custom border color
              />
              <TextField
                label="Title"
                name="title"
                value={book.title}
                onChange={handleChange}
                fullWidth
                margin="normal"
                required
                sx={{ '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': { borderColor: '#C71585' } }} // Custom border color
              />
              <TextField
                label="Author"
                name="author"
                value={book.author}
                onChange={handleChange}
                fullWidth
                margin="normal"
                sx={{ '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': { borderColor: '#C71585' } }} // Custom border color
              />
              <TextField
                label="Publication Year"
                name="publicationYear"
                value={book.publicationYear}
                onChange={handleChange}
                fullWidth
                margin="normal"
                sx={{ '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': { borderColor: '#C71585' } }} // Custom border color
              />
              <TextField
                label="Image URL"
                name="imageUrl"
                value={book.imageUrl}
                onChange={handleChange}
                fullWidth
                margin="normal"
                sx={{ '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': { borderColor: '#C71585' } }} // Custom border color
              />
              <Button
                type="submit"
                variant="contained"
                sx={{ backgroundColor: '#C71585', '&:hover': { backgroundColor: '#C71585' }, marginTop: '16px' }} // Custom button color
                startIcon={<AddCircle />} // Add an icon for adding a book
              >
                Add Book
              </Button>
            </form>
          </CardContent>
        </Card>
      </Box>
      
      <Snackbar
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        message={message}
      />
    </Container>
  );
};

export default ManageBook;
