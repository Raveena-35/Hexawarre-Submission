import React, { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Button,
  TextField,
  AppBar,
  Toolbar,
} from '@mui/material';

const ViewData = () => {
  const [books, setBooks] = useState([]);
  const [editBook, setEditBook] = useState(null);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/admin/getAllBooks');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setBooks(data);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const handleDelete = async (isbn) => {
    try {
      const response = await fetch(`http://localhost:8080/api/admin/deleteBook/${isbn}`, { method: 'DELETE' });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      fetchBooks(); // Refresh the list after deletion
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };

  const handleEdit = (book) => {
    setEditBook(book);
  };

  const handleUpdate = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/admin/updateBook/${editBook.isbn}/${editBook.title}`, { method: 'PUT' });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      setEditBook(null);
      fetchBooks(); // Refresh the list after update
    } catch (error) {
      console.error('Error updating book:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditBook({ ...editBook, [name]: value });
  };

  return (
    <Container>
      <AppBar position="static" sx={{ backgroundColor: '#C71585' }}>
        <Toolbar>
          <Typography variant="h6">Book List</Typography>
        </Toolbar>
      </AppBar>

      <Typography variant="h4" gutterBottom sx={{ marginTop: '16px', color: '#C71585' }}>
        Book List
      </Typography>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>ISBN</TableCell>
            <TableCell>Title</TableCell>
            <TableCell>Author</TableCell>
            <TableCell>Publication Year</TableCell>
            <TableCell>Image URL</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {books.map((book) => (
            <TableRow key={book.isbn}>
              <TableCell>{book.isbn}</TableCell>
              <TableCell>{book.title}</TableCell>
              <TableCell>{book.author}</TableCell>
              <TableCell>{book.publicationYear}</TableCell>
              <TableCell>{book.imageUrl}</TableCell>
              <TableCell>
                <Button
                  onClick={() => handleEdit(book)}
                  sx={{
                    backgroundColor: '#C71585',
                    color: '#fff',
                    '&:hover': { backgroundColor: '#B2226D' }, // Darker shade on hover
                    marginRight: 1,
                  }}
                >
                  Edit
                </Button>
                <Button
                  onClick={() => handleDelete(book.isbn)}
                  sx={{
                    backgroundColor: '#C71585',
                    color: '#fff',
                    '&:hover': { backgroundColor: '#B2226D' }, // Darker shade on hover
                  }}
                >
                  Delete
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editBook && (
        <div>
          <Typography variant="h6" gutterBottom>
            Edit Book
          </Typography>
          <TextField
            label="Title"
            name="title"
            value={editBook.title}
            onChange={handleChange}
            fullWidth
            margin="normal"
          />
          <Button
            onClick={handleUpdate}
            variant="contained"
            sx={{
              backgroundColor: '#C71585',
              '&:hover': { backgroundColor: '#B2226D' },
              marginTop: 2,
            }}
          >
            Update Book
          </Button>
        </div>
      )}
    </Container>
  );
};

export default ViewData;
