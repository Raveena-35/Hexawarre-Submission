import React from 'react';
import Navbar from '../Components/Navbar'; // Assuming Navbar is in the Components folder
import { Box, Typography, Card, CardContent, CardMedia, Grid, Button } from '@mui/material';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css'; // carousel styles
import { Link } from 'react-router-dom';

const books = [
  {
    title: 'Space',
    author: 'David WhiteHouse',
    img: 'https://c02.purpledshub.com/uploads/sites/48/2019/12/Space-2069-e71030a.png',
  },
  {
    title: 'The Rules Of Life',
    author: 'Richard Templar',
    img: 'https://miro.medium.com/v2/resize:fit:1200/1*JdNhnHevYPs07LYhm4vGVw.jpeg',
  },
  {
    title: 'The Energy Of Money',
    author: 'Maria Nemeth',
    img: 'https://m.media-amazon.com/images/I/716dlPZRwnL._AC_UF1000,1000_QL80_.jpg',
  },
];

const HomePage = () => {
  return (
    <div>
      {/* Navbar */}
      <Navbar />

      {/* Slider Section */}
      <Box sx={{ maxWidth: '1500px', margin: '50px auto' }}>
        <Carousel
          autoPlay
          infiniteLoop
          showThumbs={false}
          showStatus={false}
          interval={3000}
          emulateTouch
        >
          <div style={{ position: 'relative' }}>
            <img
              src="http://sigmapublicschool.in/Site/images/library.jpg"
              alt="Novel 1"
              style={{ height: '400px', objectFit: 'cover', filter: 'brightness(50%)' }}
            />
            <Typography
              variant="h5"
              align="center"
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: '#fff',
                fontStyle: 'italic',
                maxWidth: '90%',
                textShadow: '2px 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              "--Books--"
            </Typography>
          </div>
          
          <div style={{ position: 'relative' }}>
            <img
              src="https://media.istockphoto.com/id/1580615684/vector/girl-hugs-stack-of-books-standing-in-library-or-bookstore-and-rejoicing-at-opportunity-to.jpg?s=612x612&w=0&k=20&c=K51r2ZeE4RKZGHQ0DEjHtDyxdFbdvFdmU95beCvWjSw="
              alt="Novel 3"
              style={{ height: '400px', objectFit: 'cover', filter: 'brightness(50%)' }}
            />
            <Typography
              variant="h5"
              align="center"
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: '#fff',
                fontStyle: 'italic',
                maxWidth: '90%',
                textShadow: '2px 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              "A Good Book is  a True Friend." 
            </Typography>
          </div>
        </Carousel>
      </Box>

      {/* Sample Book Cards Section */}
      <Box sx={{ maxWidth: '1200px', margin: '40px auto', padding: '0 16px' }}>
        <Typography variant="h4" align="center" gutterBottom>
          Collection Of Books
        </Typography>
        <Grid container spacing={4}>
          {books.map((book, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card sx={{ maxHeight: '100%' }}>
                <CardMedia
                  component="img"
                  height="300"
                  image={book.img}
                  alt={book.title}
                  sx={{ objectFit: 'cover' }}
                />
                <CardContent>
                  <Typography variant="h6">{book.title}</Typography>
                  <Typography variant="subtitle1" color="textSecondary">
                    {book.author}
                  </Typography>
                  <Button
                    variant="contained"
                    component={Link}
                    to="/browse-products"
                    sx={{ 
                      marginTop: '10px', 
                      backgroundColor: '#C71585', 
                      '&:hover': {
                        backgroundColor: '#a0136d', // darker pink for hover effect
                      }
                    }}
                  >
                    View More
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Footer Section */}
      <Box
        sx={{
          backgroundColor: '#F7CAC9',
          color: '#000000',
          padding: '20px',
          textAlign: 'center',
          marginTop: '40px',
        }}
      >
        <Typography variant="h6">Books</Typography>
        <Typography variant="body2">
          &copy; {new Date().getFullYear()} Books. All rights reserved.
        </Typography>
      </Box>
    </div>
  );
};

export default HomePage;
