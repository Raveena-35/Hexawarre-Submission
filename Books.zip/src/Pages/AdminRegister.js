import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Alert, InputAdornment, Link } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { Person as PersonIcon, Email as EmailIcon, Lock as LockIcon } from '@mui/icons-material';

const AdminRegister = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleAdminRegister = async () => {
    const payload = {
      name: name,
      email: email,
      password: password,
      userRole: 'ADMIN',  // Admin role
    };

    try {
      const response = await fetch('http://localhost:8080/api/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        setError('Admin already exists or error in registration');
      } else {
        navigate('/admin-login');  // Redirect to admin login after successful signup
      }
    } catch (err) {
      setError('Failed to register admin. Try again later.');
    }
  };

  return (
    <Container maxWidth="xs" style={{ backgroundColor: '#f9f9f9', padding: '20px', borderRadius: '10px', boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)' }}>
      <Box textAlign="center" mb={3}>
        <Typography variant="h4" gutterBottom color="#C71585">
          Admin Registration
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Already have an account? <Link href="/admin-login" color="#C71585">Login here</Link>
        </Typography>
      </Box>
      {error && <Alert severity="error">{error}</Alert>}
      <TextField
        label="Name"
        variant="outlined"
        fullWidth
        margin="normal"
        value={name}
        onChange={(e) => setName(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <PersonIcon sx={{ color: '#C71585' }} /> {/* Changed icon color to pink */}
            </InputAdornment>
          ),
        }}
      />
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <EmailIcon sx={{ color: '#C71585' }} /> {/* Changed icon color to pink */}
            </InputAdornment>
          ),
        }}
      />
      <TextField
        label="Password"
        variant="outlined"
        fullWidth
        type="password"
        margin="normal"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <LockIcon sx={{ color: '#C71585' }} /> {/* Changed icon color to pink */}
            </InputAdornment>
          ),
        }}
      />
      <Button
        variant="contained"
        sx={{ backgroundColor: '#C71585', '&:hover': { backgroundColor: '#C71585' }, marginTop: '20px', padding: '10px' }} // Use pink color
        onClick={handleAdminRegister}
      >
        Register
      </Button>
    </Container>
  );
};

export default AdminRegister;
