import React from 'react';
import './App.css';
import SRoutes from './Routes/SRoutes';

function App() {
  return (
    <div className="App">
      <SRoutes />
    </div>
  );
}

export default App;