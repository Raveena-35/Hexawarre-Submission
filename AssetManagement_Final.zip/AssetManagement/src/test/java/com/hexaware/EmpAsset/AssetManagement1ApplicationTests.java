package com.hexaware.EmpAsset;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
