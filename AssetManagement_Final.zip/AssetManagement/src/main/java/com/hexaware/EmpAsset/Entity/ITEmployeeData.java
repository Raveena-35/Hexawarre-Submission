package com.hexaware.EmpAsset.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.hexaware.EmpAsset.Entity.Enum.EmployeeGender;
import com.hexaware.EmpAsset.Entity.Enum.Role;

@Entity
public class ITEmployeeData {

	@Id
	@Pattern(regexp = "^[A-Za-z0-9]+$")
	private String employeeId;

	@NotBlank
	private String employeePassword;

	@Size(min = 2, max = 50)
	@NotBlank
	private String employeeName;

	@Pattern(regexp = "^[\\w._]+@hexaware\\.com$")
	@NotBlank
	private String employeeEmail;

	@Enumerated(EnumType.STRING)
	private EmployeeGender employeeGender;

	@Min(18)
	@Max(60)
	private int employeeAge;

	@Pattern(regexp = "^\\d{10}$")
	@NotBlank
	private String employeePhoneNumber;

	@Size(min = 10, max = 100)
	private String employeeAddress;

	@JsonManagedReference
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<ITAssetInformation> allocatedAssets = new ArrayList<>();

	@Enumerated(EnumType.STRING)
	private Role role = Role.User;

	public ITEmployeeData() {
		super();
	}

	public ITEmployeeData(String employeeId, String employeePassword, String employeeName, String employeeEmail,
			EmployeeGender employeeGender, int employeeAge, String employeePhoneNumber, String employeeAddress,
			List<ITAssetInformation> allocatedAssets, Role role) {
		this.employeeId = employeeId;
		this.employeePassword = employeePassword;
		this.employeeName = employeeName;
		this.employeeEmail = employeeEmail;
		this.employeeGender = employeeGender;
		this.employeeAge = employeeAge;
		this.employeePhoneNumber = employeePhoneNumber;
		this.employeeAddress = employeeAddress;
		this.allocatedAssets = allocatedAssets;
		this.role = role;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeePassword() {
		return employeePassword;
	}

	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public EmployeeGender getEmployeeGender() {
		return employeeGender;
	}

	public void setEmployeeGender(EmployeeGender employeeGender) {
		this.employeeGender = employeeGender;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	public String getEmployeePhoneNumber() {
		return employeePhoneNumber;
	}

	public void setEmployeePhoneNumber(String employeePhoneNumber) {
		this.employeePhoneNumber = employeePhoneNumber;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public List<ITAssetInformation> getAllocatedAssets() {
		return allocatedAssets;
	}

	public void setAllocatedAssets(List<ITAssetInformation> allocatedAssets) {
		this.allocatedAssets = allocatedAssets;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

}
