package com.hexaware.EmpAsset.DTO;

import com.hexaware.EmpAsset.Entity.Enum.EmployeeGender;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class EmployeeDTO {

	@Pattern(regexp = "^[A-Za-z0-9]+$")
	private String employeeId;

	@NotBlank
	@Size(min = 2, max = 50)
	private String employeeName;

	@NotBlank
	@Email(message = "Invalid email format")
	@Pattern(regexp = "^[\\w._]+@hexaware\\.com$", message = "Email must end with @hexaware.com")
	private String employeeEmail;

	@NotNull
	private EmployeeGender employeeGender;

	@Min(18)
	@Max(60)
	private int employeeAge;

	@Pattern(regexp = "^\\d{10}$", message = "Phone number must be exactly 10 digits")
	private String employeePhoneNumber;

	@Size(min = 10, max = 100)
	private String employeeAddress;

	public EmployeeDTO() {
		super();
	}

	public EmployeeDTO(@Pattern(regexp = "^[A-Za-z0-9]+$") String employeeId,
			@NotBlank @Size(min = 2, max = 50) String employeeName,
			@NotBlank @Email(message = "Invalid email format") @Pattern(regexp = "^[\\w._]+@hexaware\\.com$", message = "Email must end with @hexaware.com") String employeeEmail,
			@NotNull EmployeeGender employeeGender, @Min(18) @Max(60) int employeeAge,
			@Pattern(regexp = "^\\d{10}$", message = "Phone number must be exactly 10 digits") String employeePhoneNumber,
			@Size(min = 10, max = 100) String employeeAddress) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeEmail = employeeEmail;
		this.employeeGender = employeeGender;
		this.employeeAge = employeeAge;
		this.employeePhoneNumber = employeePhoneNumber;
		this.employeeAddress = employeeAddress;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public EmployeeGender getEmployeeGender() {
		return employeeGender;
	}

	public void setEmployeeGender(EmployeeGender employeeGender) {
		this.employeeGender = employeeGender;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	public String getEmployeePhoneNumber() {
		return employeePhoneNumber;
	}

	public void setEmployeePhoneNumber(String employeePhoneNumber) {
		this.employeePhoneNumber = employeePhoneNumber;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

}
