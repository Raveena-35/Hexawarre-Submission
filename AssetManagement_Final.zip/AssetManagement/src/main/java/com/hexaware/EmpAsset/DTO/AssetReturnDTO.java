package com.hexaware.EmpAsset.DTO;

import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;

import jakarta.validation.constraints.NotNull;

public class AssetReturnDTO {

	private String assetId;

	private AssetStatus assetStatus = AssetStatus.Return_Requested;

	public AssetReturnDTO() {
		super();
	}

	public AssetReturnDTO(String assetId, @NotNull AssetStatus assetStatus) {
		super();
		this.assetId = assetId;
		this.assetStatus = assetStatus;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public AssetStatus getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(AssetStatus assetStatus) {
		this.assetStatus = assetStatus;
	}

}
