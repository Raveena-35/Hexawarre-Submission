
package com.hexaware.EmpAsset.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hexaware.EmpAsset.DTO.*;
import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;
import com.hexaware.EmpAsset.Exception.*;
import com.hexaware.EmpAsset.Service.ITAssetInformationService;

import jakarta.validation.Valid;

@RestController
public class ITAssetInformationController {

	@Autowired
	private ITAssetInformationService assetService;

	@PostMapping("/createAsset")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<?> createAsset(@Valid @RequestBody AssetDTO assetDTO) {
		try {
			AssetDTO createdAsset = assetService.saveAsset(assetDTO);
			return new ResponseEntity<>(createdAsset, HttpStatus.CREATED);
		} catch (AssetAlreadyExistsException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@GetMapping("/allAssets")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<List<AssetDTO>> getAllAssetsForAdmin() {
		List<AssetDTO> assets = assetService.getAllAssets();
		return new ResponseEntity<>(assets, HttpStatus.OK);
	}

	@GetMapping("/assetCatalogue")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<List<AssetCardDTO>> getAssetsForUser() {
		List<AssetCardDTO> assets = assetService.getAssets();
		return new ResponseEntity<>(assets, HttpStatus.OK);
	}

	@GetMapping("/requestedAssets")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<List<AssetCardDTO>> getRequestedAssetsForUser() {
		List<AssetCardDTO> availableAssets = assetService.getRequestedAssets();
		return new ResponseEntity<>(availableAssets, HttpStatus.OK);
	}

	@GetMapping("/inServiceAssets")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<List<AssetCardDTO>> getInServiceAssetsForUser() {
		List<AssetCardDTO> availableAssets = assetService.getInServiceAssets();
		return new ResponseEntity<>(availableAssets, HttpStatus.OK);
	}

	@GetMapping("/returnRequestedAssets")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<List<AssetCardDTO>> getReturnRequestedAssetsForUser() {
		List<AssetCardDTO> availableAssets = assetService.getReturnRequestedAssets();
		return new ResponseEntity<>(availableAssets, HttpStatus.OK);
	}

	@GetMapping("/searchAssetById")
	@PreAuthorize("hasAnyAuthority('User', 'Admin')")
	public ResponseEntity<?> getAssetById(@RequestParam("assetId") String assetId) {
		try {
			AssetDTO asset = assetService.getAssetById(assetId);
			if (asset.getAssetStatus() == AssetStatus.Available) {
				return new ResponseEntity<>(asset, HttpStatus.OK);
			} else {
				return new ResponseEntity<>("Asset is not available", HttpStatus.NOT_FOUND);
			}
		} catch (AssetNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/deleteAsset")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> deleteAsset(@RequestParam("assetId") String assetId) {
		try {
			String response = assetService.removeAsset(assetId);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/updateAsset")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> updateAsset(@Valid @RequestBody AssetDTO updatedAssetDTO) {
		try {
			String response = assetService.updateAsset(updatedAssetDTO.getAssetId(), updatedAssetDTO);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/searchAssetByName")
	@PreAuthorize("hasAnyAuthority('User', 'Admin')")
	public ResponseEntity<List<AssetDTO>> searchAssets(@RequestParam("assetName") String assetName) {
		List<AssetDTO> assets = assetService.findByNameContaining(assetName);
		return new ResponseEntity<>(assets, HttpStatus.OK);
	}

	@PostMapping("/requestAsset")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<String> requestAsset(@Valid @RequestBody AssetAllocationDTO assetRequest) {
		try {
			String response = assetService.requestAsset(assetRequest.getAssetId(), assetRequest.getEmployeeId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException | EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/allocateAsset")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> allocateAsset(@Valid @RequestBody AssetAllocationDTO allocationRequest) {
		try {
			String response = assetService.allocateAsset(allocationRequest.getAssetId(),
					allocationRequest.getEmployeeId(), allocationRequest.getSerialNumber());
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException | EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/rejectAssetRequest")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> assetRequestRejected(@Valid @RequestBody AssetAllocationDTO assetRequest) {
		try {
			String response = assetService.assetRequestRejected(assetRequest.getAssetId(),
					assetRequest.getEmployeeId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException | EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/serviceRequest")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<String> requestService(@Valid @RequestBody AssetServiceDTO serviceRequest) {
		try {
			String response = assetService.requestService(serviceRequest);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/returnRequest")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<String> requestReturn(@Valid @RequestBody AssetReturnDTO returnRequest) {
		try {
			String response = assetService.requestReturn(returnRequest);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/auditRequest")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> sendAuditRequest(@RequestParam("assetId") String assetId) {
		try {
			String response = assetService.sendAuditRequest(assetId);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AssetNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
}
