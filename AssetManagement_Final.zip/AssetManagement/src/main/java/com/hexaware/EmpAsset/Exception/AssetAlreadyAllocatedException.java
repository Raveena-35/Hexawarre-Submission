package com.hexaware.EmpAsset.Exception;

public class AssetAlreadyAllocatedException extends Exception {

	private static final long serialVersionUID = 1L;

	public AssetAlreadyAllocatedException(String message) {
		super(message);
	}

}
