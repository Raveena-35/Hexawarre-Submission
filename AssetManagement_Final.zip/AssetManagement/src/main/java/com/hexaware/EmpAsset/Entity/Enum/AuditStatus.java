package com.hexaware.EmpAsset.Entity.Enum;

public enum AuditStatus {
	Pending, Verified, Rejected, Not_Raised
}
