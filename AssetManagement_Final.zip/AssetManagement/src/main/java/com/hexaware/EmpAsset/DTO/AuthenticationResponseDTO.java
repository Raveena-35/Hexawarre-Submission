package com.hexaware.EmpAsset.DTO;

import com.hexaware.EmpAsset.Entity.Enum.Role;

public class AuthenticationResponseDTO {
	private String jwt;
	private Role userRole;
	private String userId;

	public String getJwt() {
		return jwt;
	}

	public void setJwt(String jwt) {
		this.jwt = jwt;
	}

	public Role getUserRole() {
		return userRole;
	}

	public void setUserRole(Role userRole) {
		this.userRole = userRole;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "AuthenticationResponse [jwt=" + jwt + ", userRole=" + userRole + ", userId=" + userId + "]";
	}

}
