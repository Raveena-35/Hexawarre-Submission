package com.hexaware.EmpAsset.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexaware.EmpAsset.DTO.EmployeeAssetsDTO;
import com.hexaware.EmpAsset.DTO.EmployeeDTO;
import com.hexaware.EmpAsset.DTO.EmployeeRegisterDTO;
import com.hexaware.EmpAsset.Entity.ITAssetInformation;
import com.hexaware.EmpAsset.Entity.ITEmployeeData;
import com.hexaware.EmpAsset.Entity.Enum.Role;
import com.hexaware.EmpAsset.Exception.AssetNotFoundException;
import com.hexaware.EmpAsset.Exception.EmployeeAlreadyExistsException;
import com.hexaware.EmpAsset.Exception.EmployeeNotFoundException;
import com.hexaware.EmpAsset.Repository.ITAssetInformationRepository;
import com.hexaware.EmpAsset.Repository.ITEmployeeDataRepository;
import com.hexaware.EmpAsset.Security.UserInfoDetails;

@Service
public class ITEmployeeDataService implements UserDetailsService {

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private ITAssetInformationRepository assetRepo;

	@Autowired
	private ITEmployeeDataRepository employeeRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<ITEmployeeData> userDetail = employeeRepo.findById(username);
		return userDetail.map(UserInfoDetails::new)
				.orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
	}

	public String saveEmployee(EmployeeRegisterDTO employeeRegisterDTO) throws EmployeeAlreadyExistsException {
		if (employeeRepo.findByEmployeeId(employeeRegisterDTO.getEmployeeId()).isPresent()) {
			throw new EmployeeAlreadyExistsException(
					"Employee with ID " + employeeRegisterDTO.getEmployeeId() + " already exists.");
		} else {
			ITEmployeeData employee = modelMapper.map(employeeRegisterDTO, ITEmployeeData.class);
			employee.setEmployeePassword(encoder.encode(employee.getEmployeePassword()));
			employeeRepo.save(employee);
			return "Employee Created...";
		}
	}

	public List<EmployeeDTO> getAllEmployees() {
		return employeeRepo.findAll().stream().filter(employee -> !employee.getEmployeeId().equals("admin"))
				.map(employee -> modelMapper.map(employee, EmployeeDTO.class)).collect(Collectors.toList());
	}

	public EmployeeDTO getEmployeeById(String employeeId) throws EmployeeNotFoundException {
		if ("admin".equals(employeeId)) {
			throw new EmployeeNotFoundException("Employee with ID " + employeeId + " cannot be accessed.");
		}
		ITEmployeeData employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new EmployeeNotFoundException("Employee with ID " + employeeId + " not found"));

		return modelMapper.map(employee, EmployeeDTO.class);
	}

	public Role getRoleById(String employeeId) throws EmployeeNotFoundException {
		ITEmployeeData employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new EmployeeNotFoundException("Employee with ID " + employeeId + " not found"));
		return employee.getRole();
	}

	public String removeEmployee(String employeeId) throws EmployeeNotFoundException {
		ITEmployeeData employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new EmployeeNotFoundException("Employee with ID " + employeeId + " not found"));
		employeeRepo.delete(employee);
		return "Employee Deleted...";
	}

	public String updateEmployee(String employeeId, EmployeeDTO updatedEmployeeDTO) throws EmployeeNotFoundException {

		ITEmployeeData existingEmployee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new EmployeeNotFoundException("Employee with ID " + employeeId + " not found"));

		existingEmployee.setEmployeeName(updatedEmployeeDTO.getEmployeeName());
		existingEmployee.setEmployeeEmail(updatedEmployeeDTO.getEmployeeEmail());
		existingEmployee.setEmployeeGender(updatedEmployeeDTO.getEmployeeGender());
		existingEmployee.setEmployeeAge(updatedEmployeeDTO.getEmployeeAge());
		existingEmployee.setEmployeePhoneNumber(updatedEmployeeDTO.getEmployeePhoneNumber());
		existingEmployee.setEmployeeAddress(updatedEmployeeDTO.getEmployeeAddress());

		employeeRepo.save(existingEmployee);
		return "Employee updated successfully";
	}

	public List<EmployeeDTO> findByNameContaining(String employeeName) {
		return employeeRepo.findByEmployeeNameContaining(employeeName).stream()
				.map(employee -> modelMapper.map(employee, EmployeeDTO.class)).collect(Collectors.toList());
	}

	public List<EmployeeAssetsDTO> getAllocatedAssetsByEmployee(String employeeId) throws EmployeeNotFoundException {
		ITEmployeeData employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new EmployeeNotFoundException("Employee with ID " + employeeId + " not found"));
		List<ITAssetInformation> allocatedAssets = employee.getAllocatedAssets();
		return allocatedAssets.stream().map(asset -> modelMapper.map(asset, EmployeeAssetsDTO.class))
				.collect(Collectors.toList());
	}

	public List<EmployeeDTO> getRequestedEmployees(String assetId)
			throws AssetNotFoundException, EmployeeNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));
		List<String> employees = asset.getRequestedByEmployees();
		List<EmployeeDTO> dtoEmployees = new ArrayList<>();
		for (String employeeId : employees) {
			ITEmployeeData dataEmployee = employeeRepo.findByEmployeeId(employeeId)
					.orElseThrow(() -> new EmployeeNotFoundException("Employee with ID " + employeeId + " not found"));
			dtoEmployees.add(modelMapper.map(dataEmployee, EmployeeDTO.class));
		}
		return dtoEmployees;
	}
}
