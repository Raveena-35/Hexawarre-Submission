package com.hexaware.EmpAsset.DTO;

import java.util.Date;

import com.hexaware.EmpAsset.Entity.Enum.AssetCategory;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;

public class AssetCardDTO {

	private String assetId;

	@NotBlank
	private String assetName;

	private String assetImgURL;

	@Positive
	private double assetPrice;

	@NotBlank
	private String assetModel;

	@PastOrPresent
	private Date manufacturingDate;

	@Future
	private Date expiryDate;

	private String assetSpecifications;

	@NotNull
	private AssetCategory assetCategory;

	public AssetCardDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssetCardDTO(String assetId, @NotBlank String assetName, String assetImgURL,
			@Positive double assetPrice, @NotBlank String assetModel, @PastOrPresent Date manufacturingDate,
			@Future Date expiryDate, String assetSpecifications, @NotNull AssetCategory assetCategory) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetImgURL = assetImgURL;
		this.assetPrice = assetPrice;
		this.assetModel = assetModel;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
		this.assetSpecifications = assetSpecifications;
		this.assetCategory = assetCategory;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetImgURL() {
		return assetImgURL;
	}

	public void setAssetImgURL(String assetImgURL) {
		this.assetImgURL = assetImgURL;
	}

	public double getAssetPrice() {
		return assetPrice;
	}

	public void setAssetPrice(double assetPrice) {
		this.assetPrice = assetPrice;
	}

	public String getAssetModel() {
		return assetModel;
	}

	public void setAssetModel(String assetModel) {
		this.assetModel = assetModel;
	}

	public Date getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(Date manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getAssetSpecifications() {
		return assetSpecifications;
	}

	public void setAssetSpecifications(String assetSpecifications) {
		this.assetSpecifications = assetSpecifications;
	}

	public AssetCategory getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(AssetCategory assetCategory) {
		this.assetCategory = assetCategory;
	}

}