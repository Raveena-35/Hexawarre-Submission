package com.hexaware.EmpAsset.Entity.Enum;

public enum IssueType {
	Normal, Malfunction, Repair
}
