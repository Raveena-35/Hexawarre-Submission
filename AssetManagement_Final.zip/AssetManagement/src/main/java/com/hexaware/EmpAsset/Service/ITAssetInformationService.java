package com.hexaware.EmpAsset.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.EmpAsset.DTO.AssetDTO;
import com.hexaware.EmpAsset.DTO.AssetReturnDTO;
import com.hexaware.EmpAsset.DTO.AssetServiceDTO;
import com.hexaware.EmpAsset.DTO.AssetCardDTO;
import com.hexaware.EmpAsset.Entity.ITAssetInformation;
import com.hexaware.EmpAsset.Entity.ITEmployeeData;
import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;
import com.hexaware.EmpAsset.Entity.Enum.AuditStatus;
import com.hexaware.EmpAsset.Entity.Enum.IssueType;
import com.hexaware.EmpAsset.Exception.AssetAlreadyExistsException;
import com.hexaware.EmpAsset.Exception.AssetNotFoundException;
import com.hexaware.EmpAsset.Exception.EmployeeNotFoundException;
import com.hexaware.EmpAsset.Repository.ITAssetInformationRepository;
import com.hexaware.EmpAsset.Repository.ITEmployeeDataRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
public class ITAssetInformationService {

	@Autowired
	private ITAssetInformationRepository assetRepo;

	@Autowired
	private ITEmployeeDataRepository employeeRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Transactional
	public AssetDTO saveAsset(AssetDTO assetDTO) throws AssetAlreadyExistsException {
		if (assetRepo.existsById(assetDTO.getAssetId())) {
			throw new AssetAlreadyExistsException("Asset ID" + assetDTO.getAssetId() + "Already Exists.");
		} else {
			ITAssetInformation itAssetInformation = modelMapper.map(assetDTO, ITAssetInformation.class);
			if (itAssetInformation.getEmployee() == null) {
				ITEmployeeData admin = employeeRepo.findByEmployeeId("admin").orElseThrow();
				itAssetInformation.setEmployee(admin);
			}
			itAssetInformation.setAssetStatus(AssetStatus.Available);
			itAssetInformation.setAuditStatus(AuditStatus.Not_Raised);
			itAssetInformation.setIssueType(IssueType.Normal);
			return modelMapper.map(assetRepo.save(itAssetInformation), AssetDTO.class);
		}
	}

	public List<AssetDTO> getAllAssets() {
		return assetRepo.findAll().stream().map(asset -> modelMapper.map(asset, AssetDTO.class))
				.collect(Collectors.toList());
	}

	public List<AssetCardDTO> getAssets() {
		List<AssetCardDTO> assets = assetRepo.findByAssetStatus(AssetStatus.Available).stream()
				.map(asset -> modelMapper.map(asset, AssetCardDTO.class)).collect(Collectors.toList());

		assets.addAll(assetRepo.findByAssetStatus(AssetStatus.Requested).stream()
				.map(asset -> modelMapper.map(asset, AssetCardDTO.class)).collect(Collectors.toList()));

		return assets;
	}

	public AssetDTO getAssetById(String assetId) throws AssetNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));
		return modelMapper.map(asset, AssetDTO.class);
	}

	public String removeAsset(String assetId) throws AssetNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));
		assetRepo.delete(asset);
		return "Asset Deleted Successfully";
	}

	public String updateAsset(String assetId, AssetDTO updatedAssetDTO) throws AssetNotFoundException {
		ITAssetInformation existingAsset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));

		modelMapper.map(updatedAssetDTO, existingAsset);
		assetRepo.save(existingAsset);
		return "Asset updated successfully";
	}

	public List<AssetDTO> findByNameContaining(String assetName) {
		return assetRepo.findByAssetNameContaining(assetName).stream()
				.map(asset -> modelMapper.map(asset, AssetDTO.class)).collect(Collectors.toList());
	}

	public String requestAsset(String assetId, String employeeId)
			throws AssetNotFoundException, EmployeeNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));
		asset.setAssetStatus(AssetStatus.Requested);
		List<String> requestedEmployees = asset.getRequestedByEmployees();
		requestedEmployees.add(employeeId);
		asset.setRequestedByEmployees(requestedEmployees);
		assetRepo.save(asset);
		return "Asset request submitted successfully.";
	}

	public String allocateAsset(String assetId, String employeeId, String serialNumber)
			throws AssetNotFoundException, EmployeeNotFoundException {
		ITAssetInformation originalAsset = assetRepo.findById(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset not found"));
		ITAssetInformation newAsset = new ITAssetInformation();
		newAsset.setAssetName(originalAsset.getAssetName());
		newAsset.setAssetCategory(originalAsset.getAssetCategory());
		newAsset.setAssetModel(originalAsset.getAssetModel());
		newAsset.setManufacturingDate(originalAsset.getManufacturingDate());
		newAsset.setExpiryDate(originalAsset.getExpiryDate());
		newAsset.setAssetSpecifications(originalAsset.getAssetSpecifications());
		newAsset.setAssetPrice(originalAsset.getAssetPrice());
		newAsset.setAssetImgURL(originalAsset.getAssetImgURL());
		newAsset.setAssetStatus(AssetStatus.Allocated);
		newAsset.setAuditStatus(originalAsset.getAuditStatus());
		newAsset.setIssueType(originalAsset.getIssueType());
		newAsset.setAllocationDate(new Date());
		newAsset.setAssetId(serialNumber);

		ITEmployeeData employee = employeeRepo.findById(employeeId)
				.orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
		newAsset.setEmployee(employee);
		assetRepo.save(newAsset);
		originalAsset.getRequestedByEmployees().remove(employeeId);
		if (originalAsset.getRequestedByEmployees().isEmpty()) {
			originalAsset.setAssetStatus(AssetStatus.Available);
		}
		assetRepo.save(originalAsset);
		return "Asset Allocated";
	}

	public String assetRequestRejected(String assetId, String employeeId)
			throws AssetNotFoundException, EmployeeNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));
		List<String> requestedEmployees = asset.getRequestedByEmployees();
		requestedEmployees.remove(employeeId);
		if (requestedEmployees.isEmpty()) {
			asset.setAssetStatus(AssetStatus.Available);
			;
		}
		asset.setRequestedByEmployees(requestedEmployees);
		assetRepo.save(asset);
		return "Asset request rejected successfully.";
	}

	public String requestService(AssetServiceDTO assetServiceDTO) throws AssetNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetServiceDTO.getAssetId()).orElseThrow(
				() -> new AssetNotFoundException("Asset with ID " + assetServiceDTO.getAssetId() + " not found"));
		asset.setAssetStatus(AssetStatus.Service);
		asset.setIssueType(assetServiceDTO.getIssueType());
		assetRepo.save(asset);
		return "Service request submitted successfully.";
	}

	public String sendAuditRequest(String assetId) throws AssetNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(assetId)
				.orElseThrow(() -> new AssetNotFoundException("Asset with ID " + assetId + " not found"));
		asset.setAuditStatus(AuditStatus.Pending);
		assetRepo.save(asset);
		return "Audit request submitted successfully.";
	}

	public String requestReturn(@Valid AssetReturnDTO returnRequest) throws AssetNotFoundException {
		ITAssetInformation asset = assetRepo.findByAssetId(returnRequest.getAssetId()).orElseThrow(
				() -> new AssetNotFoundException("Asset with ID " + returnRequest.getAssetId() + " not found"));
		if (asset.getAssetStatus() == AssetStatus.Allocated) {
			asset.setAssetStatus(AssetStatus.Return_Requested);
			assetRepo.save(asset);
			return "Return request submitted successfully.";
		} else {
			return "Return failed! The status of ";
		}
	}

	public List<AssetCardDTO> getRequestedAssets() {
		return assetRepo.findByAssetStatus(AssetStatus.Requested).stream()
				.map(asset -> modelMapper.map(asset, AssetCardDTO.class)).collect(Collectors.toList());
	}

	public List<AssetCardDTO> getInServiceAssets() {
		return assetRepo.findByAssetStatus(AssetStatus.Service).stream()
				.map(asset -> modelMapper.map(asset, AssetCardDTO.class)).collect(Collectors.toList());
	}

	public List<AssetCardDTO> getReturnRequestedAssets() {
		return assetRepo.findByAssetStatus(AssetStatus.Return_Requested).stream()
				.map(asset -> modelMapper.map(asset, AssetCardDTO.class)).collect(Collectors.toList());
	}
}
