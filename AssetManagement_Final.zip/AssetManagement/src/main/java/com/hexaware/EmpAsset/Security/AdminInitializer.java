package com.hexaware.EmpAsset.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.hexaware.EmpAsset.Entity.ITEmployeeData;
import com.hexaware.EmpAsset.Entity.Enum.EmployeeGender;
import com.hexaware.EmpAsset.Entity.Enum.Role;
import com.hexaware.EmpAsset.Repository.ITEmployeeDataRepository;

@Component
public class AdminInitializer implements CommandLineRunner {

	@Autowired
	private ITEmployeeDataRepository employeeRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public void run(String... args) throws Exception {
		if (!employeeRepo.existsById("admin")) {
			ITEmployeeData admin = new ITEmployeeData();
			admin.setEmployeeId("admin");
			admin.setEmployeePassword(passwordEncoder.encode("admin"));
			admin.setEmployeeName("Administrator");
			admin.setEmployeeEmail("admin@hexaware.com");
			admin.setEmployeeGender(EmployeeGender.Male);
			admin.setEmployeeAge(30);
			admin.setEmployeePhoneNumber("1234567890");
			admin.setEmployeeAddress("Default Admin Address");
			admin.setRole(Role.Admin);

			employeeRepo.save(admin);
			System.out.println("Admin user created with ID: admin and Password: admin");
		} else {
			System.out.println("Admin user already exists.");
		}
	}
}
