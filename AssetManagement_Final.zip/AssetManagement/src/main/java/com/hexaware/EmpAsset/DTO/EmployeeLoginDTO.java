package com.hexaware.EmpAsset.DTO;

import jakarta.validation.constraints.NotBlank;

public class EmployeeLoginDTO {
	@NotBlank
	private String employeeId;

	@NotBlank
	private String employeePassword;

	public EmployeeLoginDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeLoginDTO(@NotBlank String employeeId, @NotBlank String employeePassword) {
		super();
		this.employeeId = employeeId;
		this.employeePassword = employeePassword;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeePassword() {
		return employeePassword;
	}

	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}

}
