package com.hexaware.EmpAsset.DTO;

import com.hexaware.EmpAsset.Entity.Enum.EmployeeGender;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class EmployeeRegisterDTO {

	@Pattern(regexp = "^[A-Za-z0-9]+$")
	private String employeeId;

	@NotBlank
	@Size(min = 8, max = 50)
	private String employeePassword;

	@NotBlank
	@Email(message = "Invalid email format")
	@Pattern(regexp = "^[\\w._]+@hexaware\\.com$", message = "Email must end with @hexaware.com")
	private String employeeEmail;

	@NotBlank
	@Size(min = 2, max = 50)
	private String employeeName;

	@Min(18)
	@Max(60)
	private int employeeAge;

	@NotNull
	private EmployeeGender employeeGender;

	@Pattern(regexp = "^\\d{10}$", message = "Phone number must be exactly 10 digits")
	private String employeePhoneNumber;

	@Size(min = 10, max = 100)
	private String employeeAddress;

	public EmployeeRegisterDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeRegisterDTO(@Pattern(regexp = "^[A-Za-z0-9]+$") String employeeId,
			@NotBlank @Size(min = 8, max = 50) String employeePassword,
			@NotBlank @Email(message = "Invalid email format") @Pattern(regexp = "^[\\w._]+@hexaware\\.com$", message = "Email must end with @hexaware.com") String employeeEmail,
			@NotBlank @Size(min = 2, max = 50) String employeeName, @Min(18) @Max(60) int employeeAge,
			@NotNull EmployeeGender employeeGender,
			@Pattern(regexp = "^\\d{10}$", message = "Phone number must be exactly 10 digits") String employeePhoneNumber,
			@Size(min = 10, max = 100) String employeeAddress) {
		super();
		this.employeeId = employeeId;
		this.employeePassword = employeePassword;
		this.employeeEmail = employeeEmail;
		this.employeeName = employeeName;
		this.employeeAge = employeeAge;
		this.employeeGender = employeeGender;
		this.employeePhoneNumber = employeePhoneNumber;
		this.employeeAddress = employeeAddress;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeePassword() {
		return employeePassword;
	}

	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeAge() {
		return employeeAge;
	}

	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	public EmployeeGender getEmployeeGender() {
		return employeeGender;
	}

	public void setEmployeeGender(EmployeeGender employeeGender) {
		this.employeeGender = employeeGender;
	}

	public String getEmployeePhoneNumber() {
		return employeePhoneNumber;
	}

	public void setEmployeePhoneNumber(String employeePhoneNumber) {
		this.employeePhoneNumber = employeePhoneNumber;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

}
