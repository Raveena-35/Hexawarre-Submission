package com.hexaware.EmpAsset.DTO;

import java.util.Date;

public class EmployeeAssetsDTO {

	private String assetId;
	private String assetImgURL;
	private String assetName;
	private Date allocationDate;
	private String assetSpecifications;
	private String assetModel;
	private Date manufacturingDate;
	private Date expiryDate;

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetDescription() {
		return " Model: " + assetModel + " | " + " Specifications: " + assetSpecifications + " | "
				+ " Manufacturing Date: " + manufacturingDate + " | " + " Expiry Date: " + expiryDate;
	}

	public void setAssetSpecifications(String assetSpecifications) {
		this.assetSpecifications = assetSpecifications;
	}

	public void setAssetModel(String assetModel) {
		this.assetModel = assetModel;
	}

	public void setManufacturingDate(Date manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	public String getAssetImgURL() {
		return assetImgURL;
	}

	public void setAssetImgURL(String assetImgURL) {
		this.assetImgURL = assetImgURL;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
}
