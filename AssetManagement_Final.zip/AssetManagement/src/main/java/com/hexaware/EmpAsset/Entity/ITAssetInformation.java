package com.hexaware.EmpAsset.Entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.hexaware.EmpAsset.Entity.Enum.AssetCategory;
import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;
import com.hexaware.EmpAsset.Entity.Enum.AuditStatus;
import com.hexaware.EmpAsset.Entity.Enum.IssueType;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Future;

@Entity
public class ITAssetInformation {

	@Id
	private String assetId;

	@NotBlank
	private String assetName;

	@Enumerated(EnumType.STRING)
	private AssetCategory assetCategory;

	@NotBlank
	private String assetModel;

	@Temporal(TemporalType.DATE)
	@PastOrPresent
	private Date manufacturingDate;

	@Temporal(TemporalType.DATE)
	@Future
	private Date expiryDate;

	private String assetSpecifications;

	@NotNull
	@Min(0)
	private double assetPrice;

	private String assetImgURL;

	@Enumerated(EnumType.STRING)
	private AssetStatus assetStatus;

	@Enumerated(EnumType.STRING)
	private AuditStatus auditStatus;

	@Enumerated(EnumType.STRING)
	private IssueType issueType;

	@Temporal(TemporalType.DATE)
	private Date allocationDate;

	@ElementCollection
	private List<String> requestedByEmployees = new ArrayList<>();

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "employeeId", nullable = true)
	private ITEmployeeData employee;

	public ITAssetInformation() {
		super();
	}

	public ITAssetInformation(String assetId, String assetName, AssetCategory assetCategory, String assetModel,
			Date manufacturingDate, Date expiryDate, String assetSpecifications, double assetPrice, String assetImgURL,
			AssetStatus assetStatus, AuditStatus auditStatus, IssueType issueType, Date allocationDate,
			ITEmployeeData employee) {
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetCategory = assetCategory;
		this.assetModel = assetModel;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
		this.assetSpecifications = assetSpecifications;
		this.assetPrice = assetPrice;
		this.assetImgURL = assetImgURL;
		this.assetStatus = assetStatus;
		this.auditStatus = auditStatus;
		this.issueType = issueType;
		this.allocationDate = allocationDate;
		this.employee = employee;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public AssetCategory getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(AssetCategory assetCategory) {
		this.assetCategory = assetCategory;
	}

	public String getAssetModel() {
		return assetModel;
	}

	public void setAssetModel(String assetModel) {
		this.assetModel = assetModel;
	}

	public Date getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(Date manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getAssetSpecifications() {
		return assetSpecifications;
	}

	public void setAssetSpecifications(String assetSpecifications) {
		this.assetSpecifications = assetSpecifications;
	}

	public double getAssetPrice() {
		return assetPrice;
	}

	public void setAssetPrice(double assetPrice) {
		this.assetPrice = assetPrice;
	}

	public String getAssetImgURL() {
		return assetImgURL;
	}

	public void setAssetImgURL(String assetImgURL) {
		this.assetImgURL = assetImgURL;
	}

	public AssetStatus getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(AssetStatus assetStatus) {
		this.assetStatus = assetStatus;
	}

	public AuditStatus getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(AuditStatus auditStatus) {
		this.auditStatus = auditStatus;
	}

	public IssueType getIssueType() {
		return issueType;
	}

	public void setIssueType(IssueType issueType) {
		this.issueType = issueType;
	}

	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	public ITEmployeeData getEmployee() {
		return employee;
	}

	public void setEmployee(ITEmployeeData employee) {
		this.employee = employee;
	}

	public List<String> getRequestedByEmployees() {
		return requestedByEmployees;
	}

	public void setRequestedByEmployees(List<String> requestedByEmployees) {
		this.requestedByEmployees = requestedByEmployees;
	}

}
