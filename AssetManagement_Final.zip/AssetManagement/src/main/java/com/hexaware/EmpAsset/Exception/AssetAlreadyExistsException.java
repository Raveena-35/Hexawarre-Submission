package com.hexaware.EmpAsset.Exception;

public class AssetAlreadyExistsException extends Exception {
	private static final long serialVersionUID = 1L;

	public AssetAlreadyExistsException(String message) {
		super(message);
	}
}
