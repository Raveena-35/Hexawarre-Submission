package com.hexaware.EmpAsset.Entity.Enum;

public enum AssetCategory {
	Laptop, Furniture, Car, Gadgets
}
