package com.hexaware.EmpAsset.DTO;

import java.util.Date;

import com.hexaware.EmpAsset.Entity.Enum.AssetCategory;
import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;
import com.hexaware.EmpAsset.Entity.Enum.AuditStatus;
import com.hexaware.EmpAsset.Entity.Enum.IssueType;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;

public class AssetDTO {

	private String assetId;

	@NotBlank
	private String assetName;

	@NotNull
	private AssetCategory assetCategory;

	@NotBlank
	private String assetModel;

	@PastOrPresent
	private Date manufacturingDate;

	@Future
	private Date expiryDate;

	private String assetSpecifications;

	@Positive
	private double assetPrice;

	private String assetImgURL;

	private AssetStatus assetStatus;

	private AuditStatus auditStatus;

	private IssueType issueType;

	public AssetDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssetDTO(String assetId, @NotBlank String assetName, @NotNull AssetCategory assetCategory,
			@NotBlank String assetModel, @PastOrPresent Date manufacturingDate, @Future Date expiryDate,
			String assetSpecifications, @Positive double assetPrice, String assetImgURL) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetCategory = assetCategory;
		this.assetModel = assetModel;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
		this.assetSpecifications = assetSpecifications;
		this.assetPrice = assetPrice;
		this.assetImgURL = assetImgURL;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public AssetCategory getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(AssetCategory assetCategory) {
		this.assetCategory = assetCategory;
	}

	public String getAssetModel() {
		return assetModel;
	}

	public void setAssetModel(String assetModel) {
		this.assetModel = assetModel;
	}

	public Date getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(Date manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getAssetSpecifications() {
		return assetSpecifications;
	}

	public void setAssetSpecifications(String assetSpecifications) {
		this.assetSpecifications = assetSpecifications;
	}

	public double getAssetPrice() {
		return assetPrice;
	}

	public void setAssetPrice(double assetPrice) {
		this.assetPrice = assetPrice;
	}

	public String getAssetImgURL() {
		return assetImgURL;
	}

	public void setAssetImgURL(String assetImgURL) {
		this.assetImgURL = assetImgURL;
	}

	public AssetStatus getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(AssetStatus assetStatus) {
		this.assetStatus = assetStatus;
	}

	public AuditStatus getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(AuditStatus auditStatus) {
		this.auditStatus = auditStatus;
	}

	public IssueType getIssueType() {
		return issueType;
	}

	public void setIssueType(IssueType issueType) {
		this.issueType = issueType;
	}

}
