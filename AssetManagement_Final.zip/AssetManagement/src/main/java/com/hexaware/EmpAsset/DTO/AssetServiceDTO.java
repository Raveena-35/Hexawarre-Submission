package com.hexaware.EmpAsset.DTO;

import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;
import com.hexaware.EmpAsset.Entity.Enum.IssueType;

import jakarta.validation.constraints.NotNull;

public class AssetServiceDTO {

	private String assetId;

	@NotNull
	private AssetStatus assetStatus = AssetStatus.Service;

	@NotNull
	private IssueType issueType = IssueType.Repair;

	public AssetServiceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssetServiceDTO(String assetId, @NotNull AssetStatus assetStatus, @NotNull IssueType issueType) {
		super();
		this.assetId = assetId;
		this.assetStatus = assetStatus;
		this.issueType = issueType;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public AssetStatus getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(AssetStatus assetStatus) {
		this.assetStatus = assetStatus;
	}

	public IssueType getIssueType() {
		return issueType;
	}

	public void setIssueType(IssueType issueType) {
		this.issueType = issueType;
	}

}
