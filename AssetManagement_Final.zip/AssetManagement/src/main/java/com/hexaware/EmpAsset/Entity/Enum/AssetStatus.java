package com.hexaware.EmpAsset.Entity.Enum;

public enum AssetStatus {
	Available, Requested, Allocated, Service, Return_Requested, Returned
}