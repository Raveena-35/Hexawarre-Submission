package com.hexaware.EmpAsset.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.EmpAsset.DTO.EmployeeAssetsDTO;
import com.hexaware.EmpAsset.DTO.EmployeeDTO;
import com.hexaware.EmpAsset.DTO.EmployeeLoginDTO;
import com.hexaware.EmpAsset.DTO.EmployeeRegisterDTO;
import com.hexaware.EmpAsset.Entity.Enum.Role;
import com.hexaware.EmpAsset.Exception.AssetNotFoundException;
import com.hexaware.EmpAsset.Exception.EmployeeAlreadyExistsException;
import com.hexaware.EmpAsset.Exception.EmployeeNotFoundException;
import com.hexaware.EmpAsset.Security.JwtService;
import com.hexaware.EmpAsset.Service.ITEmployeeDataService;

import jakarta.validation.Valid;

@RestController
public class ITEmployeeDataController {

	@Autowired
	private ITEmployeeDataService employeeService;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping("/register")
	public ResponseEntity<String> registerEmployee(@Valid @RequestBody EmployeeRegisterDTO employee)
			throws EmployeeAlreadyExistsException {
		String response = employeeService.saveEmployee(employee);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@PostMapping("/login")
	public String authenticateAndGetToken(@Valid @RequestBody EmployeeLoginDTO authRequest) {
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
				authRequest.getEmployeeId(), authRequest.getEmployeePassword()));
		if (authentication.isAuthenticated()) {
			return jwtService.generateToken(authRequest.getEmployeeId());
		} else {
			throw new UsernameNotFoundException("Invalid User Request !");
		}
	}

	@GetMapping("/username")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<String> getEmployeeIdOfUser(@RequestHeader("Authorization") String token) {
		try {
			if (token.startsWith("Bearer ")) {
				token = token.substring(7);
			}
			String id = jwtService.extractUsername(token);
			return new ResponseEntity<>(id, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/showAllEmployees")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<List<EmployeeDTO>> showAllEmployees() {
		List<EmployeeDTO> employees = employeeService.getAllEmployees();
		return new ResponseEntity<>(employees, HttpStatus.OK);
	}

	@GetMapping("/showEmployeeById")
	@PreAuthorize("hasAnyAuthority('Admin', 'User')")
	public ResponseEntity<?> showEmployeeById(@RequestParam(value = "empId") String employeeId) {
		EmployeeDTO employees;
		try {
			employees = employeeService.getEmployeeById(employeeId);
			return new ResponseEntity<>(employees, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/roleOfLogin")
	@PreAuthorize("hasAnyAuthority('User', 'Admin')")
	public ResponseEntity<?> roleOfLogin(@RequestHeader("Authorization") String authorizationHeader) {
		try {
			String token = authorizationHeader.substring(7);
			String id = jwtService.extractUsername(token);
			Role roleOfUser = employeeService.getRoleById(id);
			return new ResponseEntity<>(roleOfUser, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/removeEmployees")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> removeEmployees(@RequestParam(value = "empId") String id) {
		try {
			String response = employeeService.removeEmployee(id);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/removeEmployee")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<String> removeEmployee(@RequestHeader("Authorization") String authorizationHeader) {
		try {
			String token = authorizationHeader.substring(7);
			String id = jwtService.extractUsername(token);
			String response = employeeService.removeEmployee(id);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>("An error occurred: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/updateEmployees")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<String> updateEmployees(@Valid @RequestBody EmployeeDTO updatedEmployee) {
		try {
			String result = employeeService.updateEmployee(updatedEmployee.getEmployeeId(), updatedEmployee);
			return new ResponseEntity<>(result, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/updateEmployee")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<String> updateEmployee(@RequestHeader("Authorization") String authorizationHeader,
			@Valid @RequestBody EmployeeDTO updatedEmployee) {
		try {
			String token = authorizationHeader.substring(7);
			String id = jwtService.extractUsername(token);
			String result;
			if (id.equals(updatedEmployee.getEmployeeId())) {
				result = employeeService.updateEmployee(id, updatedEmployee);
				return new ResponseEntity<>(result, HttpStatus.OK);
			} else {
				result = "Employee ID is incorrect, Please Enter your Employee ID for Security Purposes...";
				return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
			}
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/employees/findByName")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<List<EmployeeDTO>> findByNameContaining(@RequestParam(value = "empName") String name) {
		List<EmployeeDTO> employees = employeeService.findByNameContaining(name);
		return new ResponseEntity<>(employees, HttpStatus.OK);
	}

	@GetMapping("/allocatedAssets")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<?> getAllocatedAssetsByEmployee(@RequestParam(value = "empId") String employeeId) {
		try {
			List<EmployeeAssetsDTO> allocatedAssets = employeeService.getAllocatedAssetsByEmployee(employeeId);
			return new ResponseEntity<>(allocatedAssets, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/myAllocatedAssets")
	@PreAuthorize("hasAuthority('User')")
	public ResponseEntity<?> getMyAllocatedAssets(@RequestHeader("Authorization") String authorizationHeader) {
		try {
			String token = authorizationHeader.substring(7);
			String id = jwtService.extractUsername(token);
			List<EmployeeAssetsDTO> allocatedAssets = employeeService.getAllocatedAssetsByEmployee(id);
			return new ResponseEntity<>(allocatedAssets, HttpStatus.OK);
		} catch (EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/requestedEmployees")
	@PreAuthorize("hasAuthority('Admin')")
	public ResponseEntity<?> getRequestedEmployees(@RequestParam(value = "assetId") String assetId) {
		try {
			List<EmployeeDTO> requestedEmployees = employeeService.getRequestedEmployees(assetId);
			return new ResponseEntity<>(requestedEmployees, HttpStatus.OK);
		} catch (AssetNotFoundException | EmployeeNotFoundException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
}
