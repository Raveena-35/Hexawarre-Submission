package com.hexaware.EmpAsset.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.EmpAsset.Entity.ITAssetInformation;
import com.hexaware.EmpAsset.Entity.Enum.AssetStatus;

@Repository
public interface ITAssetInformationRepository extends JpaRepository<ITAssetInformation, String> {
	List<ITAssetInformation> findByAssetNameContaining(String assetName);
	List<ITAssetInformation> findByAssetStatus(AssetStatus status);
	Optional<ITAssetInformation> findByAssetId(String assetId);
}
