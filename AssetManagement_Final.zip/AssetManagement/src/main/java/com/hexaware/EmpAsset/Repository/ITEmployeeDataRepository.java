package com.hexaware.EmpAsset.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.EmpAsset.Entity.ITEmployeeData;

@Repository
public interface ITEmployeeDataRepository extends JpaRepository<ITEmployeeData, String> {
	Optional<ITEmployeeData> findByEmployeeId(String employeeId);

	List<ITEmployeeData> findByEmployeeNameContaining(String employeeName);
}
