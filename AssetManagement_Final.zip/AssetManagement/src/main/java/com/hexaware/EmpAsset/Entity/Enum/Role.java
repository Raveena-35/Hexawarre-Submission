package com.hexaware.EmpAsset.Entity.Enum;

public enum Role {
	Admin, User;
}
