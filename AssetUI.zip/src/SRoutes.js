import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Register from './components/Register';
import LoginPage from './components/LoginPage';
import EmployeeDashboard from './components/EmployeeDashboard';
import AllocatedAssets from './components/AllocatedAssets';
import AdminDashboard from './components/AdminDashboard';
import MyAccount from './components/MyAccount';
import AdminAssets from './components/AdminAssets';
import PageNotFound from "./components/PageNotFound";
import ManageEmployees from "./components/ManageEmployees"

const SRoutes = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Navigate to="/login" />} />
                <Route path="/register" element={<Register />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/employee/dashboard" element={<EmployeeDashboard />} />
                <Route path="/employee/assets" element={<AllocatedAssets />} />
                <Route path="/employee/account" element={<MyAccount />}/>
                <Route path="/admin/dashboard" element={<AdminDashboard />} />
                <Route path="/admin/assets" element={<AdminAssets />} />
                <Route path="/admin/employees" element={<ManageEmployees />} />
                <Route path="*" element={<PageNotFound />}
                />
            </Routes>
        </Router>
    );
};

export default SRoutes;