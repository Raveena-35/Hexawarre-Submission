import React, { useState } from 'react';

const UpdateModal = ({ asset, onUpdate, onClose }) => {
    const [formData, setFormData] = useState(asset);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (window.confirm("Are you sure you want to update this asset?")) {
            onUpdate(formData);
        }
    };

    return (
        <div className="modal">
            <form onSubmit={handleSubmit}>
                <label>Name:</label>
                <input name="name" value={formData.name} onChange={handleChange} />
                <button type="submit">Update</button>
                <button type="button" onClick={onClose}>Cancel</button>
            </form>
        </div>
    );
};

export default UpdateModal;
