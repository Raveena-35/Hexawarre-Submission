import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'semantic-ui-react';

const UpdateAssetModal = ({ asset, onUpdate, onClose }) => {
    const [formData, setFormData] = useState({});

    useEffect(() => {
        setFormData(asset);
    }, [asset]);

    const handleUpdate = () => {
        onUpdate(formData);
    };

    return (
        <Modal open={true} onClose={onClose}>
            <Modal.Header>Update Asset</Modal.Header>
            <Modal.Content>
                <Form>
                    <Form.Input
                        label='Asset Id'
                        value={formData.assetId}
                        onChange={(e) => setFormData({ ...formData, assetId: e.target.value })}
                        required
                    />
                    <Form.Input
                        label='Asset Name'
                        value={formData.assetName}
                        onChange={(e) => setFormData({ ...formData, assetName: e.target.value })}
                        required
                    />
                    <Form.Input
                        label='Asset Category'
                        value={formData.assetCategory}
                        onChange={(e) => setFormData({ ...formData, assetCategory: e.target.value })}
                        required
                    />
                    <Form.Input
                        label='Asset Model'
                        value={formData.assetModel}
                        onChange={(e) => setFormData({ ...formData, assetModel: e.target.value })}
                        required
                    />
                    <Form.Input
                        label='Asset Price'
                        value={formData.assetPrice}
                        onChange={(e) => setFormData({ ...formData, assetPrice: e.target.value })}
                        required
                    />
                    <Form.Input
                        label='Asset Specifications'
                        value={formData.assetSpecifications}
                        onChange={(e) => setFormData({ ...formData, assetSpecifications: e.target.value })}
                    />
                    <Form.Input
                        label='Manufacturing Date'
                        type='date'
                        value={formData.manufacturingDate}
                        onChange={(e) => setFormData({ ...formData, manufacturingDate: e.target.value })}
                        required
                    />
                    <Form.Input
                        label='Expiry Date'
                        type='date'
                        value={formData.expiryDate}
                        onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    />
                    <Form.Input
                        label='Asset Image URL'
                        value={formData.assetImgURL}
                        onChange={(e) => setFormData({ ...formData, assetImgURL: e.target.value })}
                    />
                </Form>
            </Modal.Content>
            <Modal.Actions>
                <Button negative onClick={onClose}>Cancel</Button>
                <Button positive onClick={handleUpdate}>Update Asset</Button>
            </Modal.Actions>
        </Modal>
    );
};

export default UpdateAssetModal;
