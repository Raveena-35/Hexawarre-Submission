import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import AssetCard from './AssetCard';
import { Header, Image, Icon } from 'semantic-ui-react';
import EmployeeHeader from './EmployeeHeader';

const EmployeeDashboard = () => {
    const [assetCategories, setAssetCategories] = useState({});
    const [loading, setLoading] = useState(true);
    const [loggedInEmployeeId, setLoggedInEmployeeId] = useState('');
    const [currentSlide, setCurrentSlide] = useState(0);
    const slides = [
        '/slide1.jpeg',
        '/slide2.jpeg',
        '/slide3.jpeg',
    ];

    useEffect(() => {
        const fetchAssets = async () => {
            try {
                const token = localStorage.getItem('token');
                if (!token) {
                    throw new Error("Token not found in localStorage");
                }
                
                const response = await axios.get('http://localhost:8080/assetCatalogue', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                categorizeAssets(response.data);
                
                const idResponse = await axios.get('http://localhost:8080/username', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setLoggedInEmployeeId(idResponse.data);
            } catch (error) {
                console.error('Error fetching assets:', error);
            } finally {
                setLoading(false);
            }
        };
    
        fetchAssets();
    }, []);    

    const categorizeAssets = (availableAssets) => {
        const categories = {};
        availableAssets.forEach(asset => {
            const { assetCategory } = asset;
            if (!categories[assetCategory]) {
                categories[assetCategory] = [];
            }
            categories[assetCategory].push(asset);
        });
        setAssetCategories(categories);
    };

    const handleNextSlide = useCallback(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, [slides.length]);

    const handlePreviousSlide = () => {
        setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    };

    useEffect(() => {
        const interval = setInterval(handleNextSlide, 5000);
        return () => clearInterval(interval);
    }, [handleNextSlide]);

    return (
        <div className="dashboard-container">
            <EmployeeHeader />
            <div className="slideshow-container" style={{ position: 'relative', textAlign: 'center', marginBottom: '10px' }}>
                <Image 
                    src={slides[currentSlide]} 
                    alt={`Slide ${currentSlide + 1}`} 
                    style={{ 
                        width: '80%', 
                        height: 'auto', 
                        maxHeight: '750px',
                        margin: '0 auto',
                        display: 'block'
                    }} 
                    fluid 
                />
                <Icon
                    name='chevron left'
                    size='huge'
                    onClick={handlePreviousSlide}
                    style={{
                        position: 'absolute',
                        left: '20px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        cursor: 'pointer',
                        color: 'grey',
                        zIndex: 1,
                    }}
                />
                <Icon
                    name='chevron right'
                    size='huge'
                    onClick={handleNextSlide}
                    style={{
                        position: 'absolute',
                        right: '20px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        cursor: 'pointer',
                        color: 'grey',
                        zIndex: 1,
                    }}
                />
            </div>

            <div className="asset-catalogue-container">
                <Header as='h2' content='Asset Catalogue' textAlign='center' />
                {loading ? (
                    <div>Loading assets...</div>
                ) : Object.keys(assetCategories).length > 0 ? (
                    Object.keys(assetCategories).map(category => (
                        <div key={category}>
                            <h2 className='category-title'>{category}</h2>
                            <div className="asset-card-container">
                                {assetCategories[category].map(asset => (
                                    <AssetCard key={asset.assetId} asset={asset} loggedInEmployeeId={loggedInEmployeeId} />
                                ))}
                            </div>
                        </div>
                    ))
                ) : (
                    <h1 style={{textAlign: 'center'}}>Nothing to see here for now!</h1>
                )}
            </div>
        </div>
    );
};

export default EmployeeDashboard;
