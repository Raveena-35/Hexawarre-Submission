import React from 'react';
import { Container, Divider, Grid, Header, Popup } from 'semantic-ui-react';

const Footer = () => {
  return (
    <footer>
      <Container>
        <Grid>
          <Grid.Row>
            <Grid.Column width={8}>
              <Header as='h4' textAlign='left' color='grey'>© 2024 AssetZen</Header>
            </Grid.Column>
            <Grid.Column width={8} textAlign='right'>
              <Popup
                trigger={<span style={{ cursor: 'pointer' }}>Contact Us</span>}
                content="For inquiries, please email us at support@assetzen.com or call us at (044)26440725."
                position='top center'
                inverted
              />
              <span style={{ margin: '0 10px' }}>|</span>
              <Popup
                trigger={<span style={{ cursor: 'pointer' }}>Privacy Policy</span>}
                content="Your privacy is important to us. We do not share your information with third parties."
                position='top center'
                inverted
              />
              <span style={{ margin: '0 10px' }}>|</span>
              <Popup
                trigger={<span style={{ cursor: 'pointer' }}>Terms of Use</span>}
                content="By using our services, you agree to comply with our terms and conditions."
                position='top center'
                inverted
              />
              <span style={{ margin: '0 10px' }}>|</span>
              <Popup
                trigger={<span style={{ cursor: 'pointer' }}>Cookies Policy</span>}
                content="We use cookies to enhance your experience. You can manage your cookie preferences in your browser settings."
                position='top center'
                inverted
              />
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Divider />
      </Container>
    </footer>
  );
};

export default Footer;
