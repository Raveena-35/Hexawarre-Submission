import React from 'react';
import '../App.css';

const AssetSection = ({ title, assets, onCardClick }) => (
    <div>
        <h3 className="category-title">{title}</h3>
        <div className="asset-card-container">
            {assets.map(asset => (
                <div key={asset.assetId} className="asset-card" onClick={() => onCardClick(asset)}>
                    <img src={asset.assetImgURL} alt={asset.assetName} />
                    <div className="asset-name">{asset.assetName}</div>
                </div>
            ))}
        </div>
    </div>
);


export default AssetSection;
