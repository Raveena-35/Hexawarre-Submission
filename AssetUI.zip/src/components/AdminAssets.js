import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Container, Header, Item, Modal, Form } from 'semantic-ui-react';
import AdminHeader from './AdminHeader';
import UpdateAssetModal from './UpdateAssetModal';

const AdminAssets = () => {
    const [assets, setAssets] = useState([]);
    const [selectedAsset, setSelectedAsset] = useState(null);
    const [showUpdateModal, setShowUpdateModal] = useState(false);
    const [addAssetModalOpen, setAddAssetModalOpen] = useState(false);
    const [newAsset, setNewAsset] = useState({
        assetId: '',
        assetName: '',
        assetCategory: '',
        assetModel: '',
        assetPrice: '',
        assetSpecifications: '',
        manufacturingDate: '',
        expiryDate: '',
        assetImgURL: '',
    });

    useEffect(() => {
        fetchAssets();
    }, []);

    const fetchAssets = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/allAssets', {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setAssets(response.data);
        } catch (error) {
            console.error('Error fetching assets', error);
        }
    };

    const removeAsset = async (id) => {
        if (window.confirm("Are you sure you want to remove this asset?")) {
            try {
                const token = localStorage.getItem('token');
                await axios.delete(`http://localhost:8080/deleteAsset?assetId=${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setAssets(assets.filter(asset => asset.id !== id));
                fetchAssets();
            } catch (error) {
                console.error('Error deleting asset', error);
            }
        }
    };

    const updateAsset = async (updatedAsset) => {
        try {
            const token = localStorage.getItem('token');
            await axios.put('http://localhost:8080/updateAsset', updatedAsset, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setAssets(assets.map(asset => (asset.id === updatedAsset.id ? updatedAsset : asset)));
            setShowUpdateModal(false);
        } catch (error) {
            console.error('Error updating asset', error);
        }
    };

    const openUpdateModal = (asset) => {
        setSelectedAsset(asset);
        setShowUpdateModal(true);
    };

    const closeUpdateModal = () => {
        setShowUpdateModal(false);
        setSelectedAsset(null);
    };

    const handleAddAsset = async () => {
        try {
            const token = localStorage.getItem('token');
            await axios.post('http://localhost:8080/createAsset', newAsset, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setAssets([...assets, newAsset]);
            setNewAsset({
                assetId: '',
                assetName: '',
                assetCategory: '',
                assetModel: '',
                assetPrice: '',
                assetSpecifications: '',
                manufacturingDate: '',
                expiryDate: '',
                assetImgURL: '',
            });
            setAddAssetModalOpen(false);
        } catch (error) {
            console.error('Error adding asset', error);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'Available':
            case 'Returned':
                return 'green';
            case 'Requested':
                return 'yellow';
            case 'Service':
                return 'blue';
            case 'Allocated':
                return 'red';
            case 'Return_Requested':
                return 'brown';
            default:
                return 'grey';
        }
    };

    return (
        <div className="admin-dashboard">
            <AdminHeader />
            <Container style={{ marginTop: '100px' }}>
                <Header as='h2' content='Asset Catalogue' textAlign='center' style={{ marginTop: '2em' }}>
                    <h1 style={{ textAlign: 'center' }}>Asset Catalogue</h1>
                    <Button primary floated='right' onClick={() => setAddAssetModalOpen(true)}>Add Asset</Button>
                </Header>
                <Item.Group divided>
                    {assets.map(asset => (
                        <Item key={asset.id}>
                            <Item.Image size='tiny' src={asset.assetImgURL} />
                            <Item.Content>
                                <Item.Header>
                                    {asset.assetName}
                                    <span
                                        style={{
                                            display: 'inline-block',
                                            width: '10px',
                                            height: '10px',
                                            borderRadius: '50%',
                                            backgroundColor: getStatusColor(asset.assetStatus),
                                            marginLeft: '5px',
                                        }}
                                    />
                                </Item.Header>
                                <Item.Extra style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                    <Button primary onClick={() => openUpdateModal(asset)}>Update</Button>
                                    <Button negative onClick={() => removeAsset(asset.assetId)}>Remove</Button>
                                </Item.Extra>
                            </Item.Content>
                        </Item>
                    ))}
                </Item.Group>
                
                {showUpdateModal && selectedAsset && (
                    <UpdateAssetModal 
                        asset={selectedAsset}
                        onUpdate={updateAsset}
                        onClose={closeUpdateModal}
                    />
                )}
                
                <Modal open={addAssetModalOpen} onClose={() => setAddAssetModalOpen(false)} size='small'>
                    <Modal.Header>Add New Asset</Modal.Header>
                    <Modal.Content>
                        <Form>
                            <Form.Input
                                label='Asset Id'
                                value={newAsset.assetId}
                                onChange={(e) => setNewAsset({ ...newAsset, assetId: e.target.value })}
                                required
                            />
                            <Form.Input
                                label='Asset Name'
                                value={newAsset.assetName}
                                onChange={(e) => setNewAsset({ ...newAsset, assetName: e.target.value })}
                                required
                            />
                            <Form.Select
                                label='Asset Category'
                                options={[
                                    { key: 'laptop', text: 'Laptop', value: 'Laptop' },
                                    { key: 'furniture', text: 'Furniture', value: 'Furniture' },
                                    { key: 'car', text: 'Car', value: 'Car' },
                                    { key: 'gadgets', text: 'Gadgets', value: 'Gadgets' },
                                ]}
                                value={newAsset.assetCategory}
                                onChange={(e, { value }) => setNewAsset({ ...newAsset, assetCategory: value })}
                                required
                            />
                            <Form.Input
                                label='Asset Model'
                                value={newAsset.assetModel}
                                onChange={(e) => setNewAsset({ ...newAsset, assetModel: e.target.value })}
                                required
                            />
                            <Form.Input
                                label='Asset Price'
                                value={newAsset.assetPrice}
                                onChange={(e) => setNewAsset({ ...newAsset, assetPrice: e.target.value })}
                                required
                            />
                            <Form.Input
                                label='Asset Specifications'
                                value={newAsset.assetSpecifications}
                                onChange={(e) => setNewAsset({ ...newAsset, assetSpecifications: e.target.value })}
                            />
                            <Form.Input
                                label='Manufacturing Date'
                                type='date'
                                value={newAsset.manufacturingDate}
                                onChange={(e) => setNewAsset({ ...newAsset, manufacturingDate: e.target.value })}
                                required
                            />
                            <Form.Input
                                label='Expiry Date'
                                type='date'
                                value={newAsset.expiryDate}
                                onChange={(e) => setNewAsset({ ...newAsset, expiryDate: e.target.value })}
                            />
                            <Form.Input
                                label='Asset Image URL'
                                value={newAsset.assetImgURL}
                                onChange={(e) => setNewAsset({ ...newAsset, assetImgURL: e.target.value })}
                            />
                        </Form>
                    </Modal.Content>
                    <Modal.Actions>
                        <Button negative onClick={() => setAddAssetModalOpen(false)}>Cancel</Button>
                        <Button positive onClick={handleAddAsset}>Add Asset</Button>
                    </Modal.Actions>
                </Modal>
            </Container>
        </div>
    );
};

export default AdminAssets;
