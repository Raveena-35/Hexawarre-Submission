import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Modal, Dropdown, Table, Header } from 'semantic-ui-react';
import '../App.css';
import AdminHeader from './AdminHeader';
import AssetSection from './AssetSection';

const AdminDashboard = () => {
    const [requestedAssets, setRequestedAssets] = useState([]);
    const [inServiceAssets, setInServiceAssets] = useState([]);
    const [returnRequestedAssets, setReturnRequestedAssets] = useState([]);
    const [selectedAsset, setSelectedAsset] = useState(null);
    const [openModal, setOpenModal] = useState(false);
    const [requestedEmployees, setRequestedEmployees] = useState([]);
    const [employeeDetails, setEmployeeDetails] = useState(null);
    const [allocatedAssets, setAllocatedAssets] = useState([]);
    const [serialNumber, setSerialNumber] = useState('');
    const [serialNumberModalOpen, setSerialNumberModalOpen] = useState(false);

    useEffect(() => {
        fetchAssets();
    }, []);

    const fetchAssets = async () => {
        const token = localStorage.getItem('token');

        try {
            const [requestedAssetsResponse, inServiceAssetsResponse, returnRequestedAssetsResponse] = await Promise.all([
                axios.get('http://localhost:8080/requestedAssets', { headers: { Authorization: `Bearer ${token}` } }),
                axios.get('http://localhost:8080/inServiceAssets', { headers: { Authorization: `Bearer ${token}` } }),
                axios.get('http://localhost:8080/returnRequestedAssets', { headers: { Authorization: `Bearer ${token}` } })
            ]);

            setRequestedAssets(requestedAssetsResponse.data);
            setInServiceAssets(inServiceAssetsResponse.data);
            setReturnRequestedAssets(returnRequestedAssetsResponse.data);
        } catch (error) {
            console.error('Failed to fetch assets:', error.message);
        }
    };

    const handleCardClick = async (asset) => {
        setSelectedAsset(asset);
        setOpenModal(true);

        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`http://localhost:8080/requestedEmployees?assetId=${asset.assetId}`, { headers: { Authorization: `Bearer ${token}` } });
            setRequestedEmployees(response.data);
        } catch (error) {
            console.error('Failed to fetch requested employees:', error.message);
        }
    };

    const handleEmployeeClick = async (employee) => {
        setEmployeeDetails(employee);

        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`http://localhost:8080/allocatedAssets?empId=${employee.employeeId}`, { headers: { Authorization: `Bearer ${token}` } });
            setAllocatedAssets(response.data);
        } catch (error) {
            console.error('Failed to fetch allocated assets:', error.message);
        }
    };

    const handleAccept = (employeeId) => {
        setSerialNumberModalOpen(true);
        setEmployeeDetails(prev => ({ ...prev, employeeId }));
    };

    const handleDecline = async () => {
        const employeeId = employeeDetails.employeeId;
        try {
            const token = localStorage.getItem('token');
            await axios.post('http://localhost:8080/rejectAssetRequest', {
                assetId: selectedAsset.assetId,
                employeeId: employeeId,
                serialNumber: ""
            }, { headers: { Authorization: `Bearer ${token}` } });
            fetchAssets();
            setOpenModal(false);
        } catch (error) {
            console.error('Failed to reject asset request:', error.message);
        }
    };

    const handleAllocateAsset = async () => {
        const employeeId = employeeDetails.employeeId;
        try {
            const token = localStorage.getItem('token');
            await axios.post('http://localhost:8080/allocateAsset', {
                assetId: selectedAsset.assetId,
                employeeId: employeeId,
                serialNumber: serialNumber
            }, { headers: { Authorization: `Bearer ${token}` } });
            fetchAssets();
            setSerialNumber('');
            setSerialNumberModalOpen(false);
            setOpenModal(false);
            setEmployeeDetails(null);
        } catch (error) {
            console.error('Failed to allocate asset:', error.message);
        }
    };
    

    const handleAuditRequest = async (assetId) => {
        try {
            const token = localStorage.getItem('token');
            await axios.post(`http://localhost:8080/auditRequest?assetId=${assetId}`, {}, { headers: { Authorization: `Bearer ${token}` } });
        } catch (error) {
            console.error('Failed to send audit request:', error.message);
        }
    };
    

    return (
        <div className="admin-dashboard">
            <AdminHeader />
            <Header as='h2' textAlign='center'>Admin Dashboard</Header>
            <div className="dashboard-sections">
                <AssetSection title="Asset Requested" assets={requestedAssets} onCardClick={handleCardClick} />
                <AssetSection title="Asset Service Requested" assets={inServiceAssets} onCardClick={handleCardClick} />
                <AssetSection title="Asset Return Requested" assets={returnRequestedAssets} onCardClick={handleCardClick} />
            </div>
            {selectedAsset && (
                <Modal open={openModal} onClose={() => { setOpenModal(false); setEmployeeDetails(null); }}>
                <Modal.Header>{selectedAsset.assetName}</Modal.Header>
                <Modal.Content>
                    <Header as='h4'>Asset Details</Header>
                    <p><strong>Model:</strong> {selectedAsset.assetModel}</p>
                    <p><strong>Price:</strong> {selectedAsset.assetPrice}</p>
                    <Header as='h4'>Requested Employees</Header>
                    <Dropdown text='Select Employee' fluid selection>
                        <Dropdown.Menu>
                            {requestedEmployees.map((employee) => (
                                <Dropdown.Item key={employee.employeeId} onClick={() => handleEmployeeClick(employee)}>
                                    {employee.employeeName}
                                </Dropdown.Item>
                            ))}
                        </Dropdown.Menu>
                    </Dropdown>
            
                    {employeeDetails && (
                        <>
                            <Header as='h4'>Employee Details</Header>
                            <p><strong>Name:</strong> {employeeDetails.employeeName}
                                <Button positive onClick={() => handleAccept(employeeDetails.employeeId)} style={{ marginLeft: '10px' }}>Accept</Button>
                                <Button negative onClick={() => handleDecline(employeeDetails.employeeId)} style={{ marginLeft: '10px' }}>Decline</Button>
                            </p>
                            <Header as='h4'>Allocated Assets</Header>
                            <Table celled>
                                <Table.Header>
                                    <Table.Row>
                                        <Table.HeaderCell>Asset Id</Table.HeaderCell>
                                        <Table.HeaderCell>Asset Name</Table.HeaderCell>
                                        <Table.HeaderCell>Date of Allocation</Table.HeaderCell>
                                        <Table.HeaderCell>Action</Table.HeaderCell>
                                    </Table.Row>
                                </Table.Header>
                                <Table.Body>
                                    {allocatedAssets.map(asset => (
                                        <Table.Row key={asset.assetId}>
                                            <Table.Cell>{asset.assetId}</Table.Cell>
                                            <Table.Cell>{asset.assetName}</Table.Cell>
                                            <Table.Cell>{asset.allocationDate}</Table.Cell>
                                            <Table.Cell>
                                                <Button color='blue' onClick={() => handleAuditRequest(asset.assetId)}>
                                                    Send Audit Request
                                                </Button>
                                            </Table.Cell>
                                        </Table.Row>
                                    ))}
                                </Table.Body>
                            </Table>
                        </>
                    )}
                </Modal.Content>
                <Modal.Actions>
                    <Button color='black' onClick={() => { setOpenModal(false); setEmployeeDetails(null); }}>Close</Button>
                </Modal.Actions>
            </Modal>            
            )}

            <Modal open={serialNumberModalOpen} onClose={() => setSerialNumberModalOpen(false)}>
                <Modal.Header>Allocate Asset</Modal.Header>
                <Modal.Content>
                    <Header as='h4'>Enter Serial Number for {selectedAsset?.assetName}</Header>
                    <input
                        type="number"
                        value={serialNumber}
                        onChange={(e) => setSerialNumber(e.target.value)}
                        placeholder="Serial Number"
                    />
                </Modal.Content>
                <Modal.Actions>
                    <Button color='black' onClick={() => setSerialNumberModalOpen(false)}>Cancel</Button>
                    <Button positive onClick={handleAllocateAsset}>Allocate Asset</Button>
                </Modal.Actions>
            </Modal>
        </div>
    );
};

export default AdminDashboard;
