import React, { useState, useEffect } from 'react';
import { Header, Button, Form, Modal, Container } from 'semantic-ui-react';
import axios from 'axios';
import EmployeeHeader from './EmployeeHeader';

const MyAccount = () => {
    const [employeeData, setEmployeeData] = useState({
        employeeId: '',
        employeeName: '',
        employeeEmail: '',
        employeeGender: '',
        employeeAge: '',
        employeePhoneNumber: '',
        employeeAddress: ''
    });
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        const fetchEmployeeData = async () => {
            try {
                const token = localStorage.getItem('token');
                const idResponse = await axios.get('http://localhost:8080/username', {
                    headers: { Authorization: `Bearer ${token}` }
                });

                const response = await axios.get(`http://localhost:8080/showEmployeeById`, {
                    params: { empId: idResponse.data },
                    headers: { Authorization: `Bearer ${token}` }
                });
                setEmployeeData(response.data);
            } catch (error) {
                console.error('Error fetching employee data', error);
            }
        };

        fetchEmployeeData();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEmployeeData({
            ...employeeData,
            [name]: value
        });
    };

    const handleUpdate = () => {
        setIsModalOpen(true);
    };

    const confirmUpdate = async () => {
        try {
            const token = localStorage.getItem('token');
            await axios.put('http://localhost:8080/updateEmployee', employeeData, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            alert('Employee data updated successfully');
        } catch (error) {
            console.error('Error updating employee data', error);
        }
        setIsModalOpen(false);
    };

    return (
        <div>
            <EmployeeHeader />
            <Container style={{ marginTop: '7em' }}>
            <Header as='h2' content='My Account' textAlign='center' />
                <Form>
                    <Form.Input
                        label="Employee ID"
                        name="employeeId"
                        value={employeeData.employeeId}
                        readOnly
                    />
                    <Form.Input
                        label="Name"
                        name="employeeName"
                        value={employeeData.employeeName}
                        onChange={handleInputChange}
                    />
                    <Form.Input
                        label="Email"
                        name="employeeEmail"
                        value={employeeData.employeeEmail}
                        readOnly
                    />
                    <Form.Input
                        label="Gender"
                        name="employeeGender"
                        value={employeeData.employeeGender}
                        onChange={handleInputChange}
                    />
                    <Form.Input
                        label="Age"
                        name="employeeAge"
                        value={employeeData.employeeAge}
                        onChange={handleInputChange}
                    />
                    <Form.Input
                        label="Phone Number"
                        name="employeePhoneNumber"
                        value={employeeData.employeePhoneNumber}
                        onChange={handleInputChange}
                    />
                    <Form.Input
                        label="Address"
                        name="employeeAddress"
                        value={employeeData.employeeAddress}
                        onChange={handleInputChange}
                    />
                    <Button primary onClick={handleUpdate}>Update Data</Button>
                </Form>
            </Container>

            <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
                <Modal.Header>Confirm Update</Modal.Header>
                <Modal.Content>
                    <p>Are you sure you want to update your data?</p>
                </Modal.Content>
                <Modal.Actions>
                    <Button negative onClick={() => setIsModalOpen(false)}>
                        No
                    </Button>
                    <Button positive onClick={confirmUpdate}>
                        Yes
                    </Button>
                </Modal.Actions>
            </Modal>
        </div>
    );
};

export default MyAccount;
