import React, { useEffect, useState } from 'react';
import { Button, Table, Modal, Form } from 'semantic-ui-react';
import axios from 'axios';
import AdminHeader from './AdminHeader';

const ManageEmployees = () => {
    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [formData, setFormData] = useState({
        employeeId: '',
        employeePassword: '',
        confirmPassword: '',
        employeeEmail: '',
        employeeName: '',
        employeeAge: '',
        employeeGender: 'Male',
        employeePhoneNumber: '',
        employeeAddress: '',
    });

    useEffect(() => {
        fetchEmployees();
    }, []);

    const fetchEmployees = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/showAllEmployees', {
                headers: {
                    Authorization: `Bearer ${token}`,
                }
            });
            setEmployees(response.data);
        } catch (error) {
            console.error('Error fetching employees:', error);
        }
    };

    const handleDelete = async (id) => {
        try {
            const token = localStorage.getItem('token');
            await axios.delete(`http://localhost:8080/removeEmployees?empId=${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                }
            });
            alert('Employee deleted successfully');
            fetchEmployees();
        } catch (error) {
            console.error('Error deleting employee:', error);
        }
    };

    const handleOpenModal = () => {
        setOpen(true);
    };

    const handleCloseModal = () => {
        setOpen(false);
        setFormData({
            employeeId: '',
            employeePassword: '',
            confirmPassword: '',
            employeeEmail: '',
            employeeName: '',
            employeeAge: '',
            employeeGender: 'Male',
            employeePhoneNumber: '',
            employeeAddress: '',
        });
    };

    const handleChange = (e, { name, value }) => {
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async () => {
        if (formData.employeePassword !== formData.confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        try {
            setLoading(true);
            await axios.post('http://localhost:8080/register', {
                employeeId: formData.employeeId,
                employeePassword: formData.employeePassword,
                employeeEmail: formData.employeeEmail,
                employeeName: formData.employeeName,
                employeeAge: formData.employeeAge,
                employeeGender: formData.employeeGender,
                employeePhoneNumber: formData.employeePhoneNumber,
                employeeAddress: formData.employeeAddress,
            });
            alert('Employee registered successfully');
            setLoading(false);
            handleCloseModal();
            fetchEmployees();
        } catch (error) {
            console.error('Error registering employee:', error);
            setLoading(false);
        }
    };

    return (
        <div className="manage-employees">
            <AdminHeader />
            <h2>Manage Employees</h2>
            <Button color="blue" onClick={handleOpenModal} floated="right">
                Add Employee
            </Button>
            <Table celled>
                <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell>ID</Table.HeaderCell>
                        <Table.HeaderCell>Name</Table.HeaderCell>
                        <Table.HeaderCell>Email</Table.HeaderCell>
                        <Table.HeaderCell>Gender</Table.HeaderCell>
                        <Table.HeaderCell>Phone</Table.HeaderCell>
                        <Table.HeaderCell>Address</Table.HeaderCell>
                        <Table.HeaderCell>Actions</Table.HeaderCell>
                    </Table.Row>
                </Table.Header>
                <Table.Body>
                    {employees.map(employee => (
                        <Table.Row key={employee.employeeId}>
                            <Table.Cell>{employee.employeeId}</Table.Cell>
                            <Table.Cell>{employee.employeeName}</Table.Cell>
                            <Table.Cell>{employee.employeeEmail}</Table.Cell>
                            <Table.Cell>{employee.employeeGender}</Table.Cell>
                            <Table.Cell>{employee.employeePhoneNumber}</Table.Cell>
                            <Table.Cell>{employee.employeeAddress}</Table.Cell>
                            <Table.Cell>
                                <Button color="orange" onClick={() => console.log(`Update ${employee.employeeId}`)}>
                                    Update
                                </Button>
                                <Button color="red" onClick={() => handleDelete(employee.employeeId)}>
                                    Delete
                                </Button>
                            </Table.Cell>
                        </Table.Row>
                    ))}
                </Table.Body>
            </Table>

            <Modal open={open} onClose={handleCloseModal}>
                <Modal.Header>Add New Employee</Modal.Header>
                <Modal.Content>
                    <Form loading={loading} onSubmit={handleSubmit}>
                        <Form.Input
                            label="Employee ID"
                            name="employeeId"
                            value={formData.employeeId}
                            onChange={handleChange}
                            required
                        />
                        <Form.Input
                            label="Password"
                            type="password"
                            name="employeePassword"
                            value={formData.employeePassword}
                            onChange={handleChange}
                            required
                        />
                        <Form.Input
                            label="Confirm Password"
                            type="password"
                            name="confirmPassword"
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            required
                        />
                        <Form.Input
                            label="Email"
                            name="employeeEmail"
                            value={formData.employeeEmail}
                            onChange={handleChange}
                            required
                        />
                        <Form.Input
                            label="Name"
                            name="employeeName"
                            value={formData.employeeName}
                            onChange={handleChange}
                            required
                        />
                        <Form.Input
                            label="Age"
                            type="number"
                            name="employeeAge"
                            value={formData.employeeAge}
                            onChange={handleChange}
                            required
                        />
                        <Form.Select
                            label="Gender"
                            name="employeeGender"
                            options={[
                                { key: 'm', text: 'Male', value: 'Male' },
                                { key: 'f', text: 'Female', value: 'Female' }
                            ]}
                            value={formData.employeeGender}
                            onChange={(e, { value }) => handleChange(e, { name: 'employeeGender', value })}
                            required
                        />
                        <Form.Input
                            label="Phone Number"
                            type="tel"
                            name="employeePhoneNumber"
                            value={formData.employeePhoneNumber}
                            onChange={handleChange}
                            pattern="^\d{10}$"
                            required
                        />
                        <Form.Input
                            label="Address"
                            name="employeeAddress"
                            value={formData.employeeAddress}
                            onChange={handleChange}
                            required
                        />
                    </Form>
                </Modal.Content>
                <Modal.Actions>
                    <Button onClick={handleCloseModal}>Cancel</Button>
                    <Button primary type="submit" onClick={handleSubmit}>
                        Add Employee
                    </Button>
                </Modal.Actions>
            </Modal>
        </div>
    );
};

export default ManageEmployees;
