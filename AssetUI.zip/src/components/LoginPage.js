import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../App.css'

function LoginPage() {
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8080/login', {
        employeeId: employeeId,
        employeePassword: password,
      });

      const token = response.data;

      localStorage.setItem('token', token);

      const roleResponse = await axios.get('http://localhost:8080/roleOfLogin', {
        headers: { Authorization: `Bearer ${token}` }
    });

    const role = roleResponse.data;
      if (role === 'Admin') {
        navigate('/admin/dashboard');
      } else if (role === 'User') {
        navigate('/employee/dashboard');
      } else {
        setError('Unrecognized role');
      }
    } catch (err) {
      setError('Login failed. Please check your credentials.');
    }
  };

    return (<>
    <img src='/AssetZen_bg.gif' alt="Background" />
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
                <div>
                    <label htmlFor="employeeId">Employee ID:</label>
                    <input
                        type="text"
                        id="employeeId"
                        value={employeeId}
                        onChange={(e) => setEmployeeId(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="password">Password:</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <p>
                    <a href="/forgot-password">Forgot Password?</a>
                </p>
                {error && <p style={{ color: 'red' }}>{error}</p>}
                <button type="submit">Login</button>
            </form>
            <p>
                Don't have an account? <a href="/Register">Register</a>
            </p>
        </div>
        </>);
};

export default LoginPage;
