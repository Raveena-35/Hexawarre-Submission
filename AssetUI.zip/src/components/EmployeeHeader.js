import React, { useState } from 'react';
import { Confirm, Button } from 'semantic-ui-react'; // Import Button from Semantic UI
import { useNavigate } from 'react-router-dom';

const EmployeeHeader = () => {
    const [openConfirm, setOpenConfirm] = useState(false);
    const navigate = useNavigate();

    const handleLogout = () => {
        setOpenConfirm(true);
    };

    const handleConfirmLogout = () => {
        localStorage.removeItem('token');
        navigate('/');
    };

    return (
        <>
            <header className="header1">
                <div className="header1-logo">
                    <img src="/AZ.png" alt="AssetZen Logo" />
                </div>
                <div className="header1-buttons">
                    <button onClick={() => navigate('/employee/dashboard')}>Dashboard</button>
                    <button onClick={() => navigate('/employee/assets')}>My Assets</button>
                    <button onClick={() => navigate('/employee/account')}>My Account</button>
                    <Button negative onClick={handleLogout}>
                        Logout
                    </Button>
                    <Confirm
                        open={openConfirm}
                        onCancel={() => setOpenConfirm(false)}
                        onConfirm={handleConfirmLogout}
                        content="Are you sure you want to logout?"
                    />
                </div>
            </header>
        </>
    );
}

export default EmployeeHeader;
