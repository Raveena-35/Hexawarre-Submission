import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, Container, Header, Item, Modal, Icon } from 'semantic-ui-react';
import EmployeeHeader from './EmployeeHeader';

const AllocatedAssets = () => {
    const [assets, setAssets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedAsset, setSelectedAsset] = useState(null);
    const [modalOpen, setModalOpen] = useState(false);

    useEffect(() => {
        const fetchAssets = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.get('http://localhost:8080/myAllocatedAssets', {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setAssets(response.data);
            } catch (error) {
                console.error('Error fetching assets:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchAssets();
    }, []);

    const openModal = (asset) => {
        setSelectedAsset(asset);
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
        setSelectedAsset(null);
    };

    const handleRaiseServiceRequest = async () => {
        try {
            const token = localStorage.getItem('token');
            const serviceRequestData = {
                assetId: selectedAsset.assetId,
                employeeId: localStorage.getItem('employeeId')
            };

            const response = await axios.post('http://localhost:8080/serviceRequest', serviceRequestData, {
                headers: { Authorization: `Bearer ${token}` }
            });

            console.log('Service request successful:', response.data);
            alert('Service request raised successfully');
        } catch (error) {
            console.error('Error raising service request:', error);
            alert('Failed to raise service request');
        } finally {
            closeModal();
        }
    };

    const handleReturnAsset = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.post('http://localhost:8080/returnRequest', {
                assetId: selectedAsset.assetId
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });

            console.log('Return request successful:', response.data);
            alert('Asset return request submitted successfully');
        } catch (error) {
            console.error('Error submitting return request:', error);
            alert('Failed to submit return request');
        } finally {
            closeModal();
        }
    };

    return (
        <div>
            <EmployeeHeader />
            <Container>
                <Header as='h2' content='My Allocated Assets' textAlign='center' style={{ marginTop: '5em' }} />
                {loading ? (
                    <div>Loading assets...</div>
                ) : assets.length > 0 ? (
                    <Item.Group divided>
                        {assets.map((asset, index) => (
                            <Item key={index}>
                                <Item.Image size='tiny' src={asset.assetImgURL} />
                                <Item.Content>
                                    <Item.Header>{asset.assetName}</Item.Header>
                                    <Item.Meta>
                                        <span>Date of Allocation: {new Date(asset.allocationDate).toLocaleDateString()}</span>
                                    </Item.Meta>
                                    <Item.Extra>
                                        <Button primary onClick={() => openModal(asset)}>
                                            View Details
                                            <Icon name='chevron right' />
                                        </Button>
                                    </Item.Extra>
                                </Item.Content>
                            </Item>
                        ))}
                    </Item.Group>
                ) : (
                    <Header as='h3' content='No allocated assets found.' textAlign='center' />
                )}
                {selectedAsset && (
                    <Modal open={modalOpen} onClose={closeModal} size='small'>
                        <Modal.Header>
                            {selectedAsset.assetName}
                            <Button icon='close' onClick={closeModal} floated='right' />
                        </Modal.Header>
                        <Modal.Content>
                            <Item.Group>
                                <Item>
                                    <Item.Image size='medium' src={selectedAsset.assetImgURL} />
                                    <Item.Content>
                                        <Item.Header>{selectedAsset.assetName}</Item.Header>
                                        <Item.Meta>
                                            <span>Date of Allocation: {new Date(selectedAsset.allocationDate).toLocaleDateString()}</span>
                                        </Item.Meta>
                                        <Item.Description>
                                            {selectedAsset.assetDescription}
                                        </Item.Description>
                                    </Item.Content>
                                </Item>
                            </Item.Group>
                        </Modal.Content>
                        <Modal.Actions>
                            <Button color='blue' onClick={handleRaiseServiceRequest}>
                                Raise Service Request
                            </Button>
                            <Button color='red' onClick={handleReturnAsset}>
                                Return the Asset
                            </Button>
                        </Modal.Actions>
                    </Modal>
                )}
            </Container>
        </div>
    );
};

export default AllocatedAssets;
