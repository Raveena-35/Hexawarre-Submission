import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Button, Confirm, Modal, Image, Header } from 'semantic-ui-react';
import '../App.css';

const AssetCard = ({ asset, loggedInEmployeeId }) => {
    const [openModal, setOpenModal] = useState(false);
    const [openConfirm, setOpenConfirm] = useState(false);
    const navigate = useNavigate();

    const handleRequest = async () => {
      const token = localStorage.getItem('token');
      const requestBody = { assetId: asset.assetId, employeeId: loggedInEmployeeId };
    
      try {
        await axios.post('http://localhost:8080/requestAsset', requestBody, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setOpenConfirm(false);
        setOpenModal(false);
        navigate('/employee/dashboard');
      } catch (error) {
        console.error('Failed to request asset:', error);
      }
    };
    

    return (
      <>
        <div className="asset-card" onClick={() => setOpenModal(true)}>
          <img src={asset.assetImgURL} alt={asset.assetName} />
          <div className="asset-name">{asset.assetName}</div>
        </div>
        <Modal
          onClose={() => setOpenModal(false)}
          onOpen={() => setOpenModal(true)}
          open={openModal}
          trigger={<div className="asset-card-trigger"></div>}
        >
          <Modal.Header>{asset.assetName}</Modal.Header>
          <Modal.Content image>
            <Image size='medium' src={asset.assetImgURL} wrapped />
            <Modal.Description>
              <Header>Asset Details</Header>
              <p><strong>Model:</strong> {asset.assetModel}</p>
              <p><strong>Price:</strong> {asset.assetPrice}</p>
              <p><strong>Specifications:</strong> {asset.assetSpecifications}</p>
              <p><strong>Manufacturing Date:</strong> {asset.manufacturingDate}</p>
              <p><strong>Expiry Date:</strong> {asset.expiryDate}</p>
            </Modal.Description>
          </Modal.Content>
          <Modal.Actions>
            <Button color='black' onClick={() => setOpenModal(false)}>
              Close
            </Button>
            <Button
              content="Request Asset"
              labelPosition='right'
              icon='checkmark'
              onClick={() => setOpenConfirm(true)}
              positive
            />
          </Modal.Actions>
        </Modal>
        <Confirm
          open={openConfirm}
          onCancel={() => setOpenConfirm(false)}
          onConfirm={handleRequest}
          content={`Are you sure you want to request the asset: ${asset.assetName}?`}
          confirmButton="Confirm Request"
          cancelButton="Cancel"
        />
      </>
    );
};

export default AssetCard;
