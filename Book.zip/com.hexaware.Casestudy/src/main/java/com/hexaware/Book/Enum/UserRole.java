package com.hexaware.Book.Enum;

public enum UserRole {
	
	ADMIN,
	USER

}
